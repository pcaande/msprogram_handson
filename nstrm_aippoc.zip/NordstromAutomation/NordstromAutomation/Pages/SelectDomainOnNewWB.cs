﻿using NordstromAutomation.Functions;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordstromAutomation.Pages
{
    class SelectDomainOnNewWB
    {

        private IWebDriver driver;

        Click click = new Click();
        Wait wait   = new Wait();
        Enter enter = new Enter();
        Select select = new Select();

        public SelectDomainOnNewWB(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        public void SelectDomainName(String domain)
        {
            //Select any subclass from the list 
            click.clickById(driver, "ptsd1:bldom::content");
            //Method for selecting by text value
            select.selectById(driver, "ptsd1:socSDbn::content", domain);
            
        }

        //Method for selecting by index value
        public void SelectSubclassByIndex(int index)
        {
            select.selectByIdByIndex(driver, "ptsd1:socSDbn::content", index);
        }

        public void clickOK()
        {
            click.clickByXpath(driver, ".//*[@id='ptsd1:sdOKBtn'  and @onclick='return false;']");
        }

        
    }
}
