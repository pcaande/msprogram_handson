﻿using NordstromAutomation.Functions;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordstromAutomation.Pages
{
    class TopBarGlobalPage
    {
        private IWebDriver driver;

        Click click = new Click();
        Wait wait = new Wait();
        Enter enter = new Enter();
        Select select = new Select();

        #pragma warning disable 0649
        [FindsBy(How = How.Id, Using = "b:ctbCalc")]
        private IWebElement calculatorButton;
        
        [FindsBy(How = How.Id, Using = "b:gbl_lnk:logout_link")]
        private IWebElement logoutLink;

        [FindsBy(How = How.Id, Using = "home:gbl_lnk:logout_link")]
        private IWebElement homelogoutLink;

        #pragma warning restore 0649

        public TopBarGlobalPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        public void clickCalculatorButton()
        {
            calculatorButton.Click();
            wait.WaitForInvisibilityOfElementLocatedBy(driver, By.XPath(".//*[@id='b:pt_si1']/img[@alt='Busy']"), 5);
            //wait.WaitForReady(driver, TimeSpan.FromSeconds(10));
        }

        //lougout link from an open workbook
        public void clickLogout()
        {
            wait.WaitForReady(driver, TimeSpan.FromSeconds(30));
            logoutLink.Click();
        }

        //lougout link from no open workbooks
        public void clickHomeLogout()
        {
            wait.WaitForReady(driver, TimeSpan.FromSeconds(30));
            homelogoutLink.Click();
        }


    }
}
