﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NordstromAutomation.Functions;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordstromAutomation.Pages
{
    class DimensionPage
    {
        private IWebDriver driver;

        Wait wait = new Wait();
        Click click = new Click();

        public DimensionPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        
       // [FindsBy(How = How.Id, Using = "pt1:wizDim:dimTSDC:dimPopTable::db")]
        //private IWebElement levelsTable;

        

        public void clickCancel()
        {
            click.clickById(driver, "pt1:wizDpCanl");
        }

        public String getDimensionPosition(string Dimension)
        {
            return this.driver.FindElement(By.XPath(".//*[text() = '" + Dimension + "']/ancestor::*[@_afrrk]")).GetAttribute("_afrrk").ToString();   //".//*[text() = '" + Dimension + "']/ancestor::*[@class = 'x13q']"
        }

        public String getDimensionPath(string Dimension)
        {

            if (this.driver.FindElement(By.XPath(".//*[text() = '" + Dimension + "']/ancestor::*[@_afrrk]")).GetAttribute("_afrrk").ToString().Equals("0"))
            {
                return "0";
            }

            return this.driver.FindElement(By.XPath(".//*[text() = '" + Dimension + "']/ancestor::*[@_afrrk]")).GetAttribute("_afrap").ToString();
        }

         public void validateIfMultipleTextisDisplayed(IWebDriver driver, string[] validation)
        {
            
            wait.WaitForElementId(driver, "pt1:wizDim:dimTSDC:dimPopTable::db");
            
            for (int i = 0; i < validation.Length; i++ )
            {
                Console.WriteLine("===================================================================");
                try
                {
                    Assert.IsTrue(driver.FindElement(By.Id("pt1:wizDim:dimTSDC:dimPopTable::db")).Text.Contains(validation[i]));
                    Console.WriteLine("Pass: Element " + validation[i] + " Found !");
                    Console.WriteLine("Dimension Position: " + getDimensionPosition(validation[i]));
                    Console.WriteLine("Dimension Path: " + getDimensionPath(validation[i]));
                }
                catch (AssertFailedException)
                {

                    Console.WriteLine("Fail: Element " + validation[i] + " Not Found !");
                }
                
            }

        }



    }
}
