﻿using NordstromAutomation.Functions;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordstromAutomation.Pages
{
    class LogoutPage
    {
        Click click = new Click();
        Validate validate = new Validate();
        public void SuccessfulLogOutFromHome(IWebDriver driver)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until(ExpectedConditions.ElementIsVisible(By.Id("home:gbl_lnk:logout_link")));

            click.clickById(driver, "home:gbl_lnk:logout_link");
            wait.Until(ExpectedConditions.ElementIsVisible(By.Id("j_id__ctru5")));

        }

        public void SuccessfulLogOutWithId(IWebDriver driver, String id)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until(ExpectedConditions.ElementIsVisible(By.Id(id)));

            click.clickById(driver, id);
            wait.Until(ExpectedConditions.ElementIsVisible(By.Id("j_id__ctru5")));

        }

        public void WaitForLogoutScreen(IWebDriver driver)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until(ExpectedConditions.ElementIsVisible(By.Id("j_id__ctru5")));

        }
    }
}
