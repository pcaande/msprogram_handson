﻿using NordstromAutomation.Functions;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordstromAutomation.Pages
{
    class LogoutPopUpPage
    {
        private IWebDriver driver;

        Click click = new Click();
        Wait wait = new Wait();
        Enter enter = new Enter();

        public LogoutPopUpPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        public void DoNotSave()
        {
            //Click Do not Save
            click.clickById(driver, "chkSave::content");
            click.clickById(driver, "Close::ok");
        }
    }
}
