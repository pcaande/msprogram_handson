﻿//using Microsoft.VisualStudio.TestTools.UnitTesting;
using NordstromAutomation.Functions;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordstromAutomation.Pages
{
    class MeasuresPage
    {
        private IWebDriver driver;

        Click click = new Click();
        Wait wait   = new Wait();
        Enter enter = new Enter();

        //SRP Replenishment Summary (SKU/Store/Day) 
        #pragma warning disable 0649
        [FindsBy(How = How.Id, Using = "b:dimPDC:dimTaSHDC:j_id__ctru33pc128")]
        //private IWebElement addSelectedButton;
        
        [FindsBy(How = How.Id, Using = "b:dimPDC:dimTaSHDC:j_id__ctru12pc128:dcFdAvl:findin::content")]
        private IWebElement findHiddenMeasuresTextBox;

        [FindsBy(How = How.Id, Using = "b:dimPDC:dimTaSHDC:j_id__ctru12pc128:dcFdAvl:fcn")]
        private IWebElement findNextHiddenMeasuresButton;

        [FindsBy(How = How.XPath, Using = ".//*[@id='b:dimPDC:dimTaSHDC:j_id__ctru33pc128' and @class='x228 x7j']")]
        private IWebElement enabledaddSelectedButton;

        [FindsBy(How = How.Id, Using = "wbdoc::msgDlg::_hce")]
        private IWebElement noMatchDialog;

        [FindsBy(How = How.Id, Using = "wbdoc::msgDlg::cancel")]
        private IWebElement noMatchDialog_okButton;

        [FindsBy(How = How.Id, Using = "b:j_id__ctru4pc122")]
        private IWebElement applyButton;

        [FindsBy(How = How.Id, Using = "b:j_id__ctru7pc122")]
        private IWebElement okButton;

        //SPQ Analysis
        [FindsBy(How = How.Id, Using = "b:dimPDC:dimTaSHDC:j_id__ctru12pc194:dcFdAvl:findin::content")]
        private IWebElement findHiddenMeasuresTextBox_SPQAnalysis;

        [FindsBy(How = How.Id, Using = "b:dimPDC:dimTaSHDC:j_id__ctru12pc194:dcFdAvl:fcn")]
        private IWebElement findNextHiddenMeasuresButton_SPQAnalysis;

        [FindsBy(How = How.XPath, Using = ".//*[@id='b:dimPDC:dimTaSHDC:j_id__ctru33pc194' and @class='x228 x7j']")]
        private IWebElement enabledaddSelectedButton_SPQAnalysis;

        [FindsBy(How = How.Id, Using = "b:j_id__ctru4pc188")]
        private IWebElement applyButton_SPQAnalysis;

        [FindsBy(How = How.Id, Using = "b:j_id__ctru7pc188")]
        private IWebElement okButton_SPQAnalysis;

        #pragma warning restore 0649

        public MeasuresPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        public void clickOk()
        {
            click.clickByWebElement(driver, okButton);
        }
        
        public void clickApply()
        {
            click.clickByWebElement(driver, applyButton);
        }


        public void clickOk_SPQAnalysis()
        {
            click.clickByWebElement(driver, okButton_SPQAnalysis);
        }

        public void clickApply_SPQAnalysis()
        {
            click.clickByWebElement(driver, applyButton_SPQAnalysis);
        }

        public void findThenAddMeasure(String measure)
        {
            wait.WaitForReady(driver, TimeSpan.FromSeconds(60));
            enter.enterByWebElement(driver, findHiddenMeasuresTextBox, measure);
            findNextHiddenMeasuresButton.Click();
            checkNoMatchFound(measure);
            click.clickByWebElement(driver,enabledaddSelectedButton);
            wait.WaitForReady(driver, TimeSpan.FromSeconds(10));            
        }
        
        public void findMultipleMeasuresThenAdd(String[] measures)
        {
            wait.WaitForReady(driver, TimeSpan.FromSeconds(60));

            new Actions(driver).KeyDown(Keys.Control).Build().Perform();
            for (int i = 0; i < measures.Length; i++ )
            {
                enter.enterByWebElement(driver, findHiddenMeasuresTextBox, measures[i]);
                findNextHiddenMeasuresButton.Click();
                checkNoMatchFound(measures[i]);
            }

            new Actions(driver).KeyUp(Keys.Control).Build().Perform();
            click.clickByWebElement(driver, enabledaddSelectedButton);
            wait.WaitForReady(driver, TimeSpan.FromSeconds(10));
            
        }


        public void findThenAddMeasur_SPQAnalysis(String measure)
        {
            wait.WaitForReady(driver, TimeSpan.FromSeconds(60));
            enter.enterByWebElement(driver, findHiddenMeasuresTextBox_SPQAnalysis, measure);
            findNextHiddenMeasuresButton_SPQAnalysis.Click();
            checkNoMatchFound(measure);
            click.clickByWebElement(driver, enabledaddSelectedButton_SPQAnalysis);
            wait.WaitForReady(driver, TimeSpan.FromSeconds(10));
        }

        public void scrollAndClick(By by)
        {
            IWebElement element = driver.FindElement(by);
            int elementPosition = element.Location.Y;
            String js = String.Format("window.scroll(0, %s)", elementPosition);
            ((IJavaScriptExecutor)driver).ExecuteScript(js);     
        }

        public void checkNoMatchFound(String measure)
        {
            try 
            { 
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(2));
                wait.Until(ExpectedConditions.ElementToBeClickable(noMatchDialog));
                noMatchDialog_okButton.Click();
                Console.WriteLine("Measure: "+measure+" not found!");
                Assert.Fail("Measure: " + measure + " not found!");           
            }
            catch(WebDriverTimeoutException)
            {
                Console.WriteLine("Measure "+measure+" Match found!");
            }   
        }

    }
}
