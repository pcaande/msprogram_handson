﻿using NordstromAutomation.Functions;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordstromAutomation.Pages
{
    class FramesPage
    {
        private IWebDriver driver;

        Click click = new Click();
        Wait wait = new Wait();
        Enter enter = new Enter();

        public FramesPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        public void WaitForFrameToBeAvailableAndSwitchToIt()
        {
            wait.WaitForFrameToBeAvailableAndSwitchToIt(driver, ".//iframe[starts-with(@id,'j_id')]");
        }

        public void SwitchToDefaultContent()
        {
            wait.WaitForReady(driver, TimeSpan.FromSeconds(30));
            driver.SwitchTo().DefaultContent();
        }
    }
}
