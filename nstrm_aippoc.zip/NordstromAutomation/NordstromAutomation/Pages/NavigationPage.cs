﻿using NordstromAutomation.Functions;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordstromAutomation.Pages
{
    class NavigationPage
    {
        private IWebDriver driver;

        Click click = new Click();
        Wait wait   = new Wait();
        Enter enter = new Enter();

        public NavigationPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        

        public void NavigateToAndCreateWB_AnalyzingStoreReplenishmentSalesOrdersInventory()
        {
            click.clickByXpath(driver, ".//a[contains(@id,'j_id_1::disAcr')]");
            click.clickByXpath(driver, ".//a[contains(@id,'j_id_1:2:j_id__ctru24pc')]");
        }

        public void NavigateToAndCreateWB_AnalyzingStoreReplenishmentAlertsAndException()
        {
            click.clickById(driver, "home:hnt:j_id__ctru8pc13j_id_1::disAcr");
            click.clickById(driver, "home:hnt:j_id__ctru12pc13j_id_1:1:j_id__ctru24pc13j_id_1");
        }

        public void NavigateToAndCreateWB_AnalyzingWareHouseReplenishmentOrdersInventory()
        {
            click.clickById(driver, "home:hnt:j_id__ctru8pc13j_id_1::disAcr");
            click.clickById(driver, "home:hnt:j_id__ctru12pc13j_id_1:4::di");
            click.clickById(driver, "home:hnt:j_id__ctru12pc13j_id_1:7:j_id__ctru24pc13j_id_1");
        }


    }
}
