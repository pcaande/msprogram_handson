﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NordstromAutomation.Functions;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordstromAutomation.Pages
{
    class LoginPage
    {
        Click click = new Click();
        Enter enter = new Enter();
        Wait wait = new Wait();
        Validate validate = new Validate();

        public void successfullLogin(IWebDriver driver)
        {

            //Login to AIP RPAS Fusion Client
            enter.enterById(driver, "rpaslogin:username::content", "username");
            enter.enterById(driver, "rpaslogin:pass::content", "password");
            click.ClickBy_WithTimeSpan(driver, By.Id("rpaslogin:login_btn"), TimeSpan.FromSeconds(120));
            wait.WaitForReady(driver, TimeSpan.FromSeconds(120));
            CheckForExistingLogins(driver);
        }

        public void CheckForExistingLogins(IWebDriver driver)
        {

            if (validate.IsElementPresent(driver, By.Id("home:gbl_lnk:abt_link")))
            {
                Console.WriteLine("Home Page Detected!");
            }
            else if (validate.IsElementPresent(driver, By.Id("sor1:_0")))
            {
                Console.WriteLine("Existing Login connections detected!");
                click.clickById(driver, "alc_ok");

            }
            else
            {
                Console.WriteLine("Unable to login sucessfully! Please check environment.");
                Assert.Fail("Unable to login sucessfully! Please check environment.");
            }

        }
    }
}
