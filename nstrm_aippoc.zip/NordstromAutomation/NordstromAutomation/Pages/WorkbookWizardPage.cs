﻿using NordstromAutomation.Functions;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordstromAutomation.Pages
{
    class WorkbookWizardPage
    {
         private IWebDriver driver;

        Click click = new Click();
        Wait wait   = new Wait();
        Enter enter = new Enter();
        Select select = new Select();
        ScreenShot ss = new ScreenShot();

        public WorkbookWizardPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        public void clickCancel()
        {
            click.clickById(driver, "pt1:wizCancel_btn");
        }

        public void clickOnDimensionButton()
        {
            click.clickById(driver, "pt1:AVA_PANE:j_id__ctru60pc3");
        }

        public void SearchSKU_AddAllStore_AllDays(String sku, String folder, String date)
        {
            //Search SKU and add
            enter.enterById(driver, "pt1:AVA_PANE:dcFdAvl:findin::content", sku);
            click.clickById(driver, "pt1:AVA_PANE:dcFdAvl:fcn");
            click.clickById(driver, "pt1:j_id__ctru73pc3");
            wait.WaitForInvisibilityOfElementWithText(driver, "pt1:SEL_PANE:SUPERTREE_2::db", "No data to display");
            ss.screen_shot(driver, folder, date, "SKU");
            
            //Click Next
            click.clickById(driver, "pt1:wizNext_btn");

            //Click on Add ALL on Store
            click.clickById(driver, "pt1:j_id__ctru75pc3");
            wait.WaitForInvisibilityOfElementWithText(driver, "pt1:SEL_PANE:SUPERTREE_2::db", "No data to display");
            ss.screen_shot(driver, folder, date, "Store");

            //Click Next
            click.clickById(driver, "pt1:wizNext_btn");

            //Click on Add All on Available Days
            click.clickById(driver, "pt1:j_id__ctru75pc3");
            wait.WaitForInvisibilityOfElementWithText(driver, "pt1:SEL_PANE:SUPERTREE_2::db", "No data to display");
            ss.screen_shot(driver, folder, date, "Days");

            //Click Finish
            click.clickById(driver, "pt1:wizFinish_btn");
        }

        public void AddAllSKU_AddAllStore_AllDays(String folder, String date)
        {
            //Click on Add ALL on SKUS
            click.clickById(driver, "pt1:j_id__ctru75pc3");
            wait.WaitForInvisibilityOfElementWithText(driver, "pt1:SEL_PANE:SUPERTREE_2::db", "No data to display");
            ss.screen_shot(driver, folder, date, "SKU");

            //Click Next
            click.clickById(driver, "pt1:wizNext_btn");

            //Click on Add ALL on Store
            click.clickById(driver, "pt1:j_id__ctru75pc3");
            wait.WaitForInvisibilityOfElementWithText(driver, "pt1:SEL_PANE:SUPERTREE_2::db", "No data to display");
            ss.screen_shot(driver, folder, date, "Store");

            //Click Next
            click.clickById(driver, "pt1:wizNext_btn");

            //Click on Add All on Available Days
            click.clickById(driver, "pt1:j_id__ctru75pc3");
            wait.WaitForInvisibilityOfElementWithText(driver, "pt1:SEL_PANE:SUPERTREE_2::db", "No data to display");
            ss.screen_shot(driver, folder, date, "Days");

            //Click Finish
            click.clickById(driver, "pt1:wizFinish_btn");
        }

        public void AddAllSKU_AllDays(String folder, String date)
        {
            //Click on Add ALL on SKUS
            click.clickById(driver, "pt1:j_id__ctru75pc3");
            wait.WaitForInvisibilityOfElementWithText(driver, "pt1:SEL_PANE:SUPERTREE_2::db", "No data to display");
            ss.screen_shot(driver, folder, date, "SKU");

            //Click Next
            click.clickById(driver, "pt1:wizNext_btn");

            //Click on Add All on Available Days
            click.clickById(driver, "pt1:j_id__ctru75pc3");
            wait.WaitForInvisibilityOfElementWithText(driver, "pt1:SEL_PANE:SUPERTREE_2::db", "No data to display");
            ss.screen_shot(driver, folder, date, "Days");

            //Click Finish
            click.clickById(driver, "pt1:wizFinish_btn");
        }

        public void SearchSKUandAddThenNext(String sku)
        {
            enter.enterById(driver, "pt1:AVA_PANE:dcFdAvl:findin::content", sku);
            click.clickById(driver, "pt1:AVA_PANE:dcFdAvl:fcn");
            click.clickById(driver, "pt1:j_id__ctru73pc3");
            wait.WaitForInvisibilityOfElementWithText(driver, "pt1:SEL_PANE:SUPERTREE_2::db", "No data to display");
            click.clickById(driver, "pt1:wizNext_btn");
        }

        public void AddAllStoreThenNext()
        {
            click.clickById(driver, "pt1:j_id__ctru75pc3");
            wait.WaitForInvisibilityOfElementWithText(driver, "pt1:SEL_PANE:SUPERTREE_2::db", "No data to display");
            click.clickById(driver, "pt1:wizNext_btn");
        }

        public void AddAllSkusThenNext()
        {
            //Click on Add ALL on SKUS
            click.clickById(driver, "pt1:j_id__ctru75pc3");
            wait.WaitForInvisibilityOfElementWithText(driver, "pt1:SEL_PANE:SUPERTREE_2::db", "No data to display");

            //Click Next
            click.clickById(driver, "pt1:wizNext_btn");
        }

        public void AddAllDaysThenFinish()
        {
            //Click on Add All on Available Days
            click.clickById(driver, "pt1:j_id__ctru75pc3");
            wait.WaitForInvisibilityOfElementWithText(driver, "pt1:SEL_PANE:SUPERTREE_2::db", "No data to display");

            //Click Finish
            click.clickById(driver, "pt1:wizFinish_btn");
        }

    }
}
