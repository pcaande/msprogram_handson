﻿using NordstromAutomation.Functions;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NordstromAutomation.Pages
{
    class WorkbookPage
    {
        private IWebDriver driver;

        Click click = new Click();
        Wait wait = new Wait();
        Enter enter = new Enter();
        ScreenShot ss = new ScreenShot();

        public WorkbookPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        public List<IWebElement> getWorksheetWebElement()
        {
            return new List<IWebElement>(driver.FindElements(By.XPath(".//*[@id='b:winNav::tabh::oc']/*")));
        }

        public string[] getWorkSheetIDs(List<IWebElement> children)
        {
            //Get Parent Element of the Worksheet Tabs
            
            String[] grandchildren = new String[children.Count];
            int index = 0;

            //store id attribute of children into grandchildren
            foreach (IWebElement grandchild in children)
            {
                grandchildren[index] = grandchild.GetAttribute("id") + "::disclosureAnchor";
                index++;
            };

            return grandchildren;
        }

        public void ValidateExpectedAndActualWorksheets(String folder,String date, String[] ExpectedWorksheets, String[] grandchildren, List<IWebElement> children)
        {
            String[] ActualWorksheets = new String[grandchildren.Length];
            //"Verify the worksheets available if  displayed or hidded based on FD -  Nordstrom - AIP Workbooks Templates and Profiles FD
            for (int count = 0; count < ExpectedWorksheets.Length; count++)
            {
                //get div with sheetname and re-assign to child
                children[count] = driver.FindElement(By.Id(grandchildren[count]));

                //click sheet
                click.clickById(driver, children[count].GetAttribute("id"));

                //wait for area with scroll to load
                wait.WaitForVisbilityBy(driver, By.XPath(".//*[substring(@id, string-length(@id) - string-length('DatabodyScroller11') +1) = 'DatabodyScroller11']"));


                //store sheet name to string array
                ActualWorksheets[count] = driver.FindElement(By.Id(grandchildren[count])).Text;

                Console.WriteLine("===================================================================");
                if (ExpectedWorksheets[count].Equals(ActualWorksheets[count]))
                {
                    Console.WriteLine("Sheet {0}: Passed" +
                                       "\nExpected Sheet Name: " + ExpectedWorksheets[count] +
                                       "\nActual Sheet Name: " + ActualWorksheets[count], count + 1);
                }
                else
                {
                    Console.WriteLine("Sheet {0}: Failed" +
                                       "\nExpected Sheet Name: " + ExpectedWorksheets[count] +
                                       "\nActual Sheet Name: " + ActualWorksheets[count], count + 1);
                }
                Console.WriteLine("===================================================================");
                Regex rgx = new Regex("[^a-zA-Z0-9]");
                ss.screen_shot(driver, folder, date, rgx.Replace(ActualWorksheets[count], ""));

            }

        }

        public void ClickSheetName(String sheetName)
        {
            click.clickByXpath(driver, ".//*[@id='b:winNav::tabh']//a[text() = '"+sheetName+"']");
           
            //wait for area with scroll to load
            wait.WaitForVisbilityBy(driver, By.XPath(".//*[substring(@id, string-length(@id) - string-length('DatabodyScroller11') +1) = 'DatabodyScroller11']"));

        }
        
        public void clickRulerAndSelectReplMinMax()
        {
             //click ruler icon
            click.clickById(driver, "b:w0123:mg1a:wtbDC:measureProfileMain");

            //click Select
            click.clickById(driver, "b:loadProfile");

            //click what-if Repl Min Max
            click.clickById(driver, "b:prof01j_id_23");

            //wait for area with scroll to load
            wait.WaitForVisbilityBy(driver, By.XPath(".//*[substring(@id, string-length(@id) - string-length('DatabodyScroller11') +1) = 'DatabodyScroller11']"));
    
        }

        public void clickRulerAndSelectReplTimeSupply()
        {
            //click ruler icon
            click.clickById(driver, "b:w0123:mg1a:wtbDC:measureProfileMain");

            //click Select
            click.clickById(driver, "b:loadProfile");

            //click what-if Repl Time Supply
            click.clickById(driver, "b:prof01j_id_20");

            //wait for area with scroll to load
            wait.WaitForVisbilityBy(driver, By.XPath(".//*[substring(@id, string-length(@id) - string-length('DatabodyScroller11') +1) = 'DatabodyScroller11']"));

        }

        public void ClickMeasure()
        {
            //click Measure
            click.clickById(driver, "b:w0123:mg1a:pageDC:spgl6i:0:spgl6DC:j_id__ctru6pc77");
        }

        public void WaitForAreaWithScrollToLoad()
        {
            //wait for area with scroll to load
            wait.WaitForVisbilityBy(driver, By.XPath(".//*[substring(@id, string-length(@id) - string-length('DatabodyScroller11') +1) = 'DatabodyScroller11']"));
    
        }

    }
}
