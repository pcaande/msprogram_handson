﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NordstromAutomation.Functions;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordstromAutomation.Pages
{
    class SRPReplenishmentSummary_SKUStoreDay
    {

        private IWebDriver driver;

        Click click = new Click();
        Wait wait = new Wait();
        Enter enter = new Enter();
        Select select = new Select();

        

        #pragma warning disable 0649
        [FindsBy(How = How.Id, Using = "b:w0123:mg1a:wtbDC:AV_FIND::content")]
        private IWebElement findTextBox;

        [FindsBy(How = How.Id, Using = "b:w0123:mg1a:wtbDC:bWsFndN")]
        private IWebElement findNextButton;

        [FindsBy(How = How.Id, Using = "b:butCMj_id_1")]
        private IWebElement whatifConstrainedButton;
        
        [FindsBy(How = How.Id, Using = "b:j_id__ctru38pc117::ok")]
        private IWebElement whatifConstrained_okButton;
        #pragma warning restore 0649

        public SRPReplenishmentSummary_SKUStoreDay(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        

        public void clickwhatifConstrainedButton()
        {
            whatifConstrainedButton.Click();
            wait.WaitForClickableElement(driver, whatifConstrained_okButton);
            whatifConstrained_okButton.Click();
            wait.WaitForReady(driver, TimeSpan.FromSeconds(10));
        }

        public void FindNext()
        {
            click.clickByWebElement(driver, findNextButton);
        }

        public void Search(String searchkey)
        {   
            enter.enterByWebElement(driver, findTextBox, searchkey);
        }

        public string returnColumnNumberFromId(string id)
        {
            return id.Substring(id.IndexOf("p:") + 2, id.LastIndexOf(":") - (id.IndexOf("p:") + 2));
        }

        public string getNumberOfFirstEditableField()
        {
            string objectid = driver.FindElement(By.XPath("(.//td[@id[starts-with(.,'b:w0123:mg1a:p:')] and @style='text-align:right;'])[1]")).GetAttribute("id");
            return objectid.Substring(objectid.IndexOf("p:") + 2, objectid.LastIndexOf(":") - (objectid.IndexOf("p:") + 2));
        }

        public string getFirstCellofFirstEditableColumn(int diffOfFirstEditable)
        {
                try
                {
                    //get id of first editable cell
                    string objectid = driver.FindElement(By.XPath("(.//td[@id[starts-with(.,'b:w0123:mg1a:p:')] and @style='text-align:left;'])[1]")).GetAttribute("id");
                    int firstcell = Int32.Parse(objectid.Substring(objectid.IndexOf("p:") + 2, objectid.LastIndexOf(":") - (objectid.IndexOf("p:") + 2)));
                    int SATP = firstcell - diffOfFirstEditable;
                    for (int i = 0; i < 100; i++ )
                    {

                        if (driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + (SATP + i) + ":j_id__ctru40pc73']//img")).GetAttribute("title").Equals("Checked"))
                        {
                            Console.WriteLine("getColumnOfStoreAvailableToPlanisChecked: " + (SATP + i).ToString());
                            return (SATP+i).ToString();
                        }
                    }
                    return (SATP + 100).ToString();
                }
                catch (NoSuchElementException)
                {
                    Assert.Fail("No Editable Columns displayed on current view of the Workbook!");
                    return "No Editable Columns displayed on current view of the Workbook!";
                }  
        }

        public string getStoreAvailableToPlanOfFirstEditableColumn()
        {
            int firstId = Int32.Parse(getNumberOfFirstEditableField());
            firstId = firstId - 480;
            return firstId.ToString();
        }

        public decimal getValueFromCell(int column)
        {
            String value = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:"+column.ToString()+":j_id__ctru40pc73']")).Text;
            Console.WriteLine("getValueFromCell of Column("+column+"): "+value);
            return decimal.Parse(value);
        }

        public String getColumnOfStoreAvailableToPlanisChecked()
        {
            int colNum = Int32.Parse(getStoreAvailableToPlanOfFirstEditableColumn());
            //will only check up to 100 days. Change value if more is needed.
            for (int i = 0; i < 100; i++)
            {
                colNum = colNum + i;
                if (driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + colNum.ToString() + ":j_id__ctru40pc73']//img")).GetAttribute("title").Equals("Checked"))
                {
                    Console.WriteLine("getColumnOfStoreAvailableToPlanisChecked: " + colNum.ToString());
                    return colNum.ToString();   
                }
            }

            return "No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock";
        }

        public String getColumnOfStoreAvailableToPlanisChecked_FromSelectedColumn()
        {
            int colNum = Int32.Parse(getFirstSelectedReadOnlyCell());
            //will only check up to 100 days. Change value if more is needed.
            for (int i = 0; i < 100; i++)
            {
                
                if (driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + colNum.ToString() + ":j_id__ctru40pc73']//img")).GetAttribute("title").Equals("Checked"))
                {
                    Console.WriteLine("getColumnOfStoreAvailableToPlanisChecked: " + colNum.ToString());
                    return colNum.ToString();
                }else
                {
                    colNum++;
                }
            }

            return "No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock";
        }
        
        public String getColumnOfStoreAvailableToPlanisChecked_And_PIislessthanSS()
        {
            int colNum = Int32.Parse(getColumnOfStoreAvailableToPlanisChecked_FromSelectedColumn());//getStoreAvailableToPlanOfFirstEditableColumn()
            //will only check up to 100 days. Change value if more is needed.
            for (int i = 0; i < 100; i++ )
            {
                wait.WaitForReady(driver, TimeSpan.FromSeconds(30));
                if(driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:"+colNum.ToString()+":j_id__ctru40pc73']//img")).GetAttribute("title").Equals("Checked"))
                {
                    String date = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + (colNum + 30) + ":j_id__ctru40pc73']/span")).Text;
                    Console.WriteLine("Selected date: "+date);
                    String nextDate = Convert.ToDateTime(date).AddDays(2).ToString("M/dd/yyyy");
                    Console.WriteLine("Next date: " + nextDate);
                    int colPI = colNum + 840;
                    int colSS = colNum + 990;

                    click.clickById(driver,"b:w0123:mg1a:p:" + (colPI - 30) + ":j_id__ctru40pc73");
                    moveCellDown(7);
                    if (getValueFromCell(colPI) < getValueFromCell(colSS))
                    {
                        Console.WriteLine("getColumnOfStoreAvailableToPlanisChecked_And_PIislessthanSS: " + colNum.ToString());
                        return colNum.ToString();
                    }
                    Search("Store Available to Plan Receipt");
                    FindNext();
                    wait.WaitForReady(driver, TimeSpan.FromSeconds(30));
                    Search(nextDate);
                    FindNext();
                    wait.WaitForReady(driver, TimeSpan.FromSeconds(30));
                    wait.WaitForVisbilityBy(driver, By.XPath(".//*[substring(@id, string-length(@id) - string-length('DatabodyScroller11') +1) = 'DatabodyScroller11']"));
                    colNum = Int32.Parse(returnColumnNumberFromId(driver.FindElement(By.XPath("(.//*[@_oc='#DDDDDD'])[1]")).GetAttribute("id")));
                    colNum++;
                }else
                { 
                    colNum++;
                }
            }
            
            return "No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock";
        }
        public String[] MinMaxValidations()
        {

            String column = getColumnOfStoreAvailableToPlanisChecked_And_PIislessthanSS();
            String[] values = new String[8];
            //Validate what IF Values
            int ColumnOfProjectedInventoryWhatIf = Int32.Parse(column) + 840;
            int ColumnOfRecieptPlanWhatIf = Int32.Parse(column) + 870;
            int ColumnOfRecieptPlanDollarWhatIf = Int32.Parse(column) + 900;
            values[0] = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + ColumnOfRecieptPlanWhatIf.ToString() + ":j_id__ctru40pc73']")).Text;
            values[1] = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + ColumnOfRecieptPlanDollarWhatIf.ToString() + ":j_id__ctru40pc73']")).Text.Replace(",","");
            values[1] = values[1].Replace("$","");
            values[7] = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + ColumnOfProjectedInventoryWhatIf.ToString() + ":j_id__ctru40pc73']")).Text;
            Console.WriteLine("Actual RecieptPlanWhatIf(" + ColumnOfRecieptPlanWhatIf + "): " + values[0]);
            Console.WriteLine("Actual RecieptPlanDollarWhatIf(" + ColumnOfRecieptPlanDollarWhatIf + "): " + values[1]);
            Console.WriteLine("Actual ProjectedInventoryWhatIf(" + ColumnOfProjectedInventoryWhatIf + "): " + values[7]);
            //validate Elevated Values
            int ColumnOfSafetyStockStore = Int32.Parse(column) + 660;
            int ColumnOfRecieptPlan = Int32.Parse(column) + 240;
            int ColumnOfRecieptPlanDollar = Int32.Parse(column) + 270;
            int ColumnOfReceiveUptoLevelStore = Int32.Parse(column) + 330;
            int ColumnOfReceiptPointStore = Int32.Parse(column) + 360;

            values[2] = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + ColumnOfSafetyStockStore.ToString() + ":j_id__ctru40pc73']")).Text;
            values[3] = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + ColumnOfRecieptPlan.ToString() + ":j_id__ctru40pc73']")).Text;
            values[4] = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + ColumnOfRecieptPlanDollar.ToString() + ":j_id__ctru40pc73']")).Text.Replace(",", "");
            values[4] = values[4].Replace("$", "");
            values[5] = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + ColumnOfReceiveUptoLevelStore.ToString() + ":j_id__ctru40pc73']")).Text;
            values[6] = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + ColumnOfReceiptPointStore.ToString() + ":j_id__ctru40pc73']")).Text;
            Console.WriteLine("Actual SafetyStockStore(" + ColumnOfSafetyStockStore + "): " + values[2]);
            Console.WriteLine("Actual RecieptPlan(" + ColumnOfRecieptPlan + "): " + values[3]);
            Console.WriteLine("Actual RecieptPlanDollar(" + ColumnOfRecieptPlanDollar + "): " + values[4]);
            Console.WriteLine("Actual ReceiveUptoLevelStore(" + ColumnOfReceiveUptoLevelStore + "): " + values[5]);
            Console.WriteLine("Actual ReceiptPointStore(" + ColumnOfReceiptPointStore + "): " + values[6]);
            return values;
        }

        public String[] TimeSupplyValidations_Whatif()
        {
            String column = getColumnOfStoreAvailableToPlanisChecked_FromSelectedColumn();
            String[] values = new String[3];

            int RecieptPlanWhatIfCell = Int32.Parse(column) + 900;
            click.clickById(driver, "b:w0123:mg1a:p:" + RecieptPlanWhatIfCell.ToString() + ":j_id__ctru40pc73");
            moveCellDown(4);

            int ColumnOfReceiveUpToLevelWhatIf = Int32.Parse(column) + 930;
            int ColumnOfRecieptPointWhatIf = Int32.Parse(column) + 960;
            int ColumnOfSafetyStockWhatIf = Int32.Parse(column) + 990;

            values[0] = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + ColumnOfReceiveUpToLevelWhatIf.ToString() + ":j_id__ctru40pc73']")).Text;
            values[1] = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + ColumnOfRecieptPointWhatIf.ToString() + ":j_id__ctru40pc73']")).Text;
            values[2] = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + ColumnOfSafetyStockWhatIf.ToString() + ":j_id__ctru40pc73']")).Text;
            Console.WriteLine("Actual Receive Up To Level WhatIf(" + ColumnOfReceiveUpToLevelWhatIf + "): " + values[0]);
            Console.WriteLine("Actual Reciept Point WhatIf(" + ColumnOfRecieptPointWhatIf + "): " + values[1]);
            Console.WriteLine("Actual Safety Stock WhatIf(" + ColumnOfSafetyStockWhatIf + "): " + values[2]);
            
            return values;
        }

        public String[] TimeSupplyValidations_Elevated()
        {
            String column = getColumnOfStoreAvailableToPlanisChecked_FromSelectedColumn();
            String[] values = new String[3];

            int ColumnOfSafetyStockStore = Int32.Parse(column) + 660;
            int ColumnOfRUTLStore = Int32.Parse(column) + 330;
            int ColumnOfReceiptPointStore = Int32.Parse(column) + 360;

            values[0] = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + ColumnOfSafetyStockStore.ToString() + ":j_id__ctru40pc73']")).Text;
            values[1] = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + ColumnOfRUTLStore.ToString() + ":j_id__ctru40pc73']")).Text;
            values[2] = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + ColumnOfReceiptPointStore.ToString() + ":j_id__ctru40pc73']")).Text;
            Console.WriteLine("Actual Safety Stock Store(" + ColumnOfSafetyStockStore + "): " + values[0]);
            Console.WriteLine("Actual RUTL Store(" + ColumnOfRUTLStore + "): " + values[1]);
            Console.WriteLine("Actual Receipt Point Store(" + ColumnOfReceiptPointStore + "): " + values[2]);

            return values;
        }

        //Receipt Plan (What-if) - Store
        public String getValueOfRecieptPlanWhatIf()
        {
            String column = getColumnOfStoreAvailableToPlanisChecked_And_PIislessthanSS();

            if (column.Equals("No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock"))
            {
                Assert.Fail("No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock");
                return null;
            }else
            {
                int colNum = Int32.Parse(column) + 750;
                return driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + colNum + ":j_id__ctru40pc73']")).Text;
            }
        }

        //Receipt Plan $ (What-If) - Store
        public String getValueOfRecieptPlanDollarWhatIf()
        {
            String column = getColumnOfStoreAvailableToPlanisChecked_And_PIislessthanSS();
            Actions action = new Actions(driver);
            if (column.Equals("No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock"))
            {
                Assert.Fail("No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock");
                return null;
            }
            else
            {
                int colNum = Int32.Parse(column) + 720;
                //action.MoveToElement(driver.FindElement(By.XPath(".//*[@class='x1tm']//*[@class='x1u0' and text()='Receipt Plan (What-If) - Store']")));
                return driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + colNum + ":j_id__ctru40pc73']")).Text;
            }
        }

        //Receipt Plan - Store
        public String getValueOfRecieptPlan()
        {
            String column = getColumnOfStoreAvailableToPlanisChecked_And_PIislessthanSS();

            if (column.Equals("No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock"))
            {
                Assert.Fail("No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock");
                return null;
            }
            else
            {
                int colNum = Int32.Parse(column) + 240;
                return driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + colNum + ":j_id__ctru40pc73']")).Text;
            }
        }

        //Receipt Plan $ - Store
        public String getValueOfRecieptPlanDollar()
        {
            String column = getColumnOfStoreAvailableToPlanisChecked_And_PIislessthanSS();

            if (column.Equals("No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock"))
            {
                Assert.Fail("No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock");
                return null;
            }
            else
            {
                int colNum = Int32.Parse(column) + 270;
                return driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + colNum + ":j_id__ctru40pc73']")).Text;
            }
        }

        //Safety Stock - Store 
        public String getValueOfSafetyStockStore()
        {
            String column = getColumnOfStoreAvailableToPlanisChecked_And_PIislessthanSS();

            if (column.Equals("No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock"))
            {
                Assert.Fail("No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock");
                return null;
            }
            else
            {
                int colNum = Int32.Parse(column) + 510;
                return driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + colNum + ":j_id__ctru40pc73']")).Text;
            }
        }

        //Receive Up to Level - Store
        public String getValueOfReceiveUptoLevelStore()
        {
            String column = getColumnOfStoreAvailableToPlanisChecked_And_PIislessthanSS();

            if (column.Equals("No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock"))
            {
                Assert.Fail("No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock");
                return null;
            }
            else
            {
                int colNum = Int32.Parse(column) + 360;
                return driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + colNum + ":j_id__ctru40pc73']")).Text;
            }
        }

        //validate Receipt Point - Store
        public String getValueOfReceiptPointStore()
        {
            String column = getColumnOfStoreAvailableToPlanisChecked_And_PIislessthanSS();

            if (column.Equals("No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock"))
            {
                Assert.Fail("No Store Available To Plan is Checked! OR No Project Inventory is Less than the Safety Stock");
                return null;
            }
            else
            {
                int colNum = Int32.Parse(column) + 390;
                return driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + colNum + ":j_id__ctru40pc73']")).Text;
            }
        }

        public void EnterIncrementPercentStore(string value)
        {
            int firstId = Int32.Parse(getLastSelectedReadOnlyCell());
            firstId = firstId - 450;
            click.clickById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73");
            enter.enterById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73:d::content", value);
        }


        public void EnterMaxStockStore(string value)
        {
            int firstId = Int32.Parse(getLastSelectedReadOnlyCell());
            firstId = firstId - 420;
            click.clickById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73");
            enter.enterById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73:d::content", value);
        }

        public void EnterMinStockStore(string value)
        {
            int firstId = Int32.Parse(getLastSelectedReadOnlyCell());
            firstId = firstId - 390;
            click.clickById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73");
            enter.enterById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73:d::content", value);                                   
        }

        public void EnterMaxTimeSupplyDaysStore(string value)
        {
            int firstId = Int32.Parse(getLastSelectedReadOnlyCell());
            firstId = firstId - 90;
            click.clickById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73");
            enter.enterById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73:d::content", value);
        }

        public void EnterMinTimeSupplyDaysStore(string value)
        {
            int firstId = Int32.Parse(getLastSelectedReadOnlyCell());
            firstId = firstId - 60;
            click.clickById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73");
            enter.enterById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73:d::content", value);
        }

        public void SelectReplenishmentMethodStoreTimeSupply(string value)
        {
            int firstId = Int32.Parse(getLastSelectedReadOnlyCell());
            firstId = firstId - 390;
            click.clickById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73");
            select.selectById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73:l::content", value);
        }

        public void SelectReplenishmentMethodStore(string value)
        {
            int firstId = Int32.Parse(getLastSelectedReadOnlyCell());
            firstId = firstId - 360;
            click.clickById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73");
            select.selectById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73:l::content", value);
        }

        public void SelectDropDownFieldFromTopWithIncrement(string value, int increment)
        {
            int firstId = Int32.Parse(getFirstSelectedReadOnlyCell());
            firstId = firstId + increment;
            click.clickById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73");
            select.selectById(driver, "b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73:l::content", value);
        }
        
        public string  get_RUTL_Whatif()
        {
            int firstId = Int32.Parse(getLastSelectedReadOnlyCell());
            firstId = firstId - 540;
            Console.WriteLine("Actual RUTL: " + driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text);
            return driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text;
        }

        public string getFieldValueFromBottomWithIncrement(string fieldname, int increment)
        {
            int firstId = Int32.Parse(getLastSelectedReadOnlyCell());
            firstId = firstId - increment;
            Console.WriteLine(fieldname+"("+increment+"): " + driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text);
            return driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text;
        }

        public string getFieldValueFromTopWithIncrement(int increment)
        {
            int firstId = Int32.Parse(getFirstSelectedReadOnlyCell());
            firstId = firstId + increment;
            Console.WriteLine("Field(" + increment + "): " + driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text);
            return driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text;
        }

        public string get_RP_Whatif()
        {
            int firstId = Int32.Parse(getLastSelectedReadOnlyCell());
            firstId = firstId - 510;
            Console.WriteLine("Actual RP: " + driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text);
            return driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text;
        }

        public string get_SS_Whatif()
        {
            int firstId = Int32.Parse(getLastSelectedReadOnlyCell());
            firstId = firstId - 480;
            Console.WriteLine("Actual SS: " + driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text);
            return driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text;
        }

        public string getReplenishmentMethodStore()
        {
            int firstId = Int32.Parse(getFirstSelectedReadOnlyCell());
            firstId = firstId + 450;
            Console.WriteLine("Actual Replenishment Method Store: " + driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text);
            return driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text;
        }

        public string getMinTimeSupplyDays()
        {
            int firstId = Int32.Parse(getFirstSelectedReadOnlyCell());
            firstId = firstId + 510;
            Console.WriteLine("Actual Min Time Supply Days: " + driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text);
            return driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text;
        }

        public string getMaxTimeSupplyDays()
        {
            int firstId = Int32.Parse(getFirstSelectedReadOnlyCell());
            firstId = firstId + 570;
            Console.WriteLine("Actual Max Time Supply Days: " + driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text);
            return driver.FindElement(By.Id("b:w0123:mg1a:p:" + firstId.ToString() + ":j_id__ctru40pc73")).Text;
        }

        public string getFirstSelectedReadOnlyCell()
        {
            return returnColumnNumberFromId(driver.FindElement(By.XPath("(.//*[@_oc='#DDDDDD'])[1]")).GetAttribute("id"));
        }

        public string getLastSelectedReadOnlyCell()
        {
            return returnColumnNumberFromId(driver.FindElement(By.XPath("(.//*[@_oc='#DDDDDD'])[last()]")).GetAttribute("id"));
        }

        public void moveCellDown(int times)
        {
            for (int i = 0; i < times; i++ )
            {
                new Actions(driver).KeyDown(Keys.Control).SendKeys(Keys.ArrowDown).KeyUp(Keys.Control).Build().Perform();
                wait.waitForBusyTopRightImageToDisappear(driver);
            }            
        }

        public void moveCellUp(int times)
        {
            for (int i = 0; i < times; i++)
            {
                new Actions(driver).KeyDown(Keys.Control).SendKeys(Keys.ArrowUp).KeyUp(Keys.Control).Build().Perform();
                wait.waitForBusyTopRightImageToDisappear(driver);
            }
        }

        public void SearchAndFind(string search, int noOfClickonFind)
        {
            Search(search);
            for (int i = 0; i < noOfClickonFind; i++ )
            { 
                FindNext();
                wait.WaitForReady(driver, TimeSpan.FromSeconds(30));
            }
        }

        public string PositionToFirstColumnWithEditableFields(string postionMeasure, int noOfClickFindNext, int diffFromFirstEditable)
        {
            //SearchAndFind(DateTime.Today.ToString("MM/dd/yyyy"), 1);
            String firstcell = getFirstCellofFirstEditableColumn(diffFromFirstEditable);
            String date = driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + (Int32.Parse(firstcell) + 30) + ":j_id__ctru40pc73']/span")).Text;
            //if(date="")date = DateTime.Today.ToString("M/dd/yyyy")
            String trueDate = Convert.ToDateTime(date).AddDays(2).ToString("M/dd/yyyy");
            SearchAndFind(postionMeasure, noOfClickFindNext);
            SearchAndFind(trueDate, 1);

            return trueDate;
        }

        public Boolean IsTodaysColumnEditable()
        {
            SearchAndFind(DateTime.Today.ToString("M/dd/yyyy"), 1);//MM/dd/yyyy
            //SearchAndFind("11/12/2016", 1);
            //SearchAndFind(truedate, 1);
            wait.WaitForReady(driver, TimeSpan.FromSeconds(30));
            String firstcell = getFirstSelectedReadOnlyCell();
            int ERMid = Int32.Parse(firstcell) + 420;
            Console.WriteLine("Selected Column ERM Style: " + driver.FindElement(By.Id("b:w0123:mg1a:p:" + ERMid + ":j_id__ctru40pc73")).GetAttribute("style"));
            // add to logic to include a check for available to plan = yes
            if (driver.FindElement(By.Id("b:w0123:mg1a:p:" + ERMid + ":j_id__ctru40pc73")).GetAttribute("style").Equals("text-align: left;") && driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + firstcell + ":j_id__ctru40pc73']//img")).GetAttribute("title").Equals("Checked"))
            {
                Console.WriteLine(DateTime.Today.ToString("M/dd/yyyy") + " Column Editable");
                return true;
            }
            
            else{
                
                return false;
            }
        }

        public String CheckIfSelectedDateHasAvailableToPlanAndEditable(String truedate)
        {
            //SearchAndFind(DateTime.Today.ToString("M/dd/yyyy"), 1);//MM/dd/yyyy
            //SearchAndFind("11/12/2016", 1);

            String date = truedate;
            
            //Will loop to 50 days checking if that column is editable and has available to plan is yes.
            for (int i = 0; i < 50; i++ )
            {
                date = Convert.ToDateTime(truedate).AddDays(i).ToString("M/dd/yyyy");
                SearchAndFind(date, 1);
                wait.WaitForReady(driver, TimeSpan.FromSeconds(30));
                String firstcell = getFirstSelectedReadOnlyCell();
                int ERMid = Int32.Parse(firstcell) + 420;
                Console.WriteLine("Selected Column ERM Style: " + driver.FindElement(By.Id("b:w0123:mg1a:p:" + ERMid + ":j_id__ctru40pc73")).GetAttribute("style"));
                if (driver.FindElement(By.Id("b:w0123:mg1a:p:" + ERMid + ":j_id__ctru40pc73")).GetAttribute("style").Equals("text-align: left;") && driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + firstcell + ":j_id__ctru40pc73']//img")).GetAttribute("title").Equals("Checked"))
                {
                    Console.WriteLine(date + " Column Editable And Available To Plan is Yes");
                    return date;
                }
               
                
            }
            Console.WriteLine("After checking for 50 days, No Data is editable");
            return date;
        }

        public String CheckIfSelectedDateHasAvailableToPlanAndEditableWithIncrementValue(String truedate, int increment)
        {
            String date = truedate;

            for (int i = 0; i < 50; i++)
            {
                date = Convert.ToDateTime(truedate).AddDays(i).ToString("M/dd/yyyy");
                SearchAndFind(date, 1);
                wait.WaitForReady(driver, TimeSpan.FromSeconds(30));
                String firstcell = getFirstSelectedReadOnlyCell();
                int ERMid = Int32.Parse(firstcell) + increment;
                Console.WriteLine("Selected Column ERM Style: " + driver.FindElement(By.Id("b:w0123:mg1a:p:" + ERMid + ":j_id__ctru40pc73")).GetAttribute("style"));
                if (driver.FindElement(By.Id("b:w0123:mg1a:p:" + ERMid + ":j_id__ctru40pc73")).GetAttribute("style").Equals("text-align: left;") && driver.FindElement(By.XPath(".//*[@id='b:w0123:mg1a:p:" + firstcell + ":j_id__ctru40pc73']//img")).GetAttribute("title").Equals("Checked"))
                {
                    Console.WriteLine(date + " Column Editable");
                    return date;
                }
            }

            Console.WriteLine("After checking for 50 days, No Data is editable");
            return date;
        }
    }
}

