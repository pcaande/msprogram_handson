﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NordstromAutomation.Functions;
using OpenQA.Selenium;
using NordstromAutomation.Pages;
using System.Collections.Generic;

namespace NordstromAutomation.TestScripts.Replenishment_Management
{
    /// <summary>
    /// TSC.03.09.01
    /// Validate the Store Replenishment Plan for the active SKU in Store 
    /// when Replenishment Method is Time Supply and On Sale is present date 
    /// and Off Sale is 3/31/2016.
    /// 
    /// </summary>
    [TestClass]
    public class TS03_09_01 : TestBase
    {

        //Functions
        Click click = new Click();
        Enter enter = new Enter();
        Select select = new Select();
        Validate val = new Validate();
        Wait wait = new Wait();
        ScreenShot ss = new ScreenShot();

        //Pages
        MeasuresPage mp = new MeasuresPage(driver);
        SRPReplenishmentSummary_SKUStoreDay srp = new SRPReplenishmentSummary_SKUStoreDay(driver);
        TopBarGlobalPage tbgp = new TopBarGlobalPage(driver);
        NavigationPage np = new NavigationPage(driver);
        FramesPage fp = new FramesPage(driver);
        SelectDomainOnNewWB sdonw = new SelectDomainOnNewWB(driver);
        WorkbookWizardPage wwp = new WorkbookWizardPage(driver);
        WorkbookPage wp = new WorkbookPage(driver);
        LogoutPopUpPage lpup = new LogoutPopUpPage(driver);
        LogoutPage logout = new LogoutPage();
        LoginPage login = new LoginPage();

        //Parameters for screenshot folder and filename(date)
        String folder = "TS03_09_01";
        String date = DateTime.Now.ToString("MMddyyyy_hhmm");


        String DomainName = "global";
        String sku = "3441"; //91941646
        String InputDate = DateTime.Today.ToString("M/dd/yyyy");

        ///Test Script
        String ReplenishmentMethodStoreTimeSupply = "Time Supply";
        int MaxTimeSupplyDaysStore = 5;
        int MinTimeSupplyDaysStore = 2;

        //Validation
        String ReceiveUpToLevel = "300.00";
        String ReceiptPoint = "100.00";
        String SafetyStock = "100.00";

        

        [TestMethod]
        public void TS03_09_01_TestScript()
        {

            //Login
            login.successfullLogin(driver);
            ss.screen_shot(driver, folder, date, "AfterLogin");

            //Navigate to worksheet by creating workbook under this path  Analyzing activity
            //> Store Replenishment task and Sales 
            //> Sales, Order, Inventory
            np.NavigateToAndCreateWB_AnalyzingStoreReplenishmentSalesOrdersInventory();

            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //Select any subclass from the list 
            sdonw.SelectDomainName(DomainName);
            ss.screen_shot(driver, folder, date, "Subclass");

            //Click on OK button 
            sdonw.clickOK();


            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //search sku ad, add all associated stores, add all days
            wwp.SearchSKU_AddAllStore_AllDays(sku, folder, date);

            //Long load creating workbook
            wait.WaitForLoadingCreatingWorkbook(driver);


            //wait for workbook to load.
            fp.SwitchToDefaultContent();
            wait.WaitForWorkBookToLoad(driver);
            ss.screen_shot(driver, folder, date, "WorkBookCreated");

            //click sheet
            wp.ClickSheetName("SRP Replenishment Summary (SKU/Store/Day)");
            ss.screen_shot(driver, folder, date, "SRP Replenishment Summary_StoreSkuDay");

            wp.clickRulerAndSelectReplTimeSupply();
            
            //click Measure
            wp.ClickMeasure();    
            

            //Click and add Demo Stock - Store    
            mp.findThenAddMeasure("Replenishment Method - Store");
            mp.findThenAddMeasure("Max Safety Stock Units (expanded)");
            mp.findThenAddMeasure("Max Safety Stock Units - Store");
            mp.findThenAddMeasure("Max Sellable Quantity - Store");
            mp.findThenAddMeasure("Min Safety Stock Units (expanded)");
            mp.findThenAddMeasure("Min Safety Stock Units - Store");
            mp.findThenAddMeasure("Min Sales Stock - Store");
            mp.findThenAddMeasure("Boundary Stock (expanded) - Store");
            mp.findThenAddMeasure("Boundary Stock - Store");
            mp.findThenAddMeasure("Customer Orders over Review Time - Store");

            mp.findThenAddMeasure("Max Time Supply Days - Store");
            mp.findThenAddMeasure("Min Time Supply Days - Store");
            mp.findThenAddMeasure("Promotion Presentation Stock Factor - Store");
            mp.findThenAddMeasure("Safety Stock Level Factor (expanded) - Store");
            mp.findThenAddMeasure("Safety Stock Level Factor - Store");
            mp.findThenAddMeasure("Time Supply Horizon - Store");
         

            ss.screen_shot(driver, folder, date, "AddedMeasures");
            //click apply then ok
            mp.clickApply();
            wait.WaitForReady(driver, TimeSpan.FromSeconds(10));
            mp.clickOk();
            wait.WaitForReady(driver, TimeSpan.FromSeconds(30));

            String truedate = InputDate;
            
            truedate = srp.CheckIfSelectedDateHasAvailableToPlanAndEditable(truedate);
            srp.SearchAndFind("Time Supply Horizon - Store", 2);
            srp.SearchAndFind(truedate, 1);
            
            //String truedate = srp.PositionToFirstColumnWithEditableFields("Time Supply Horizon - Store", 2);

            //wait for area with scroll to load
            wp.WaitForAreaWithScrollToLoad();

            ss.screen_shot(driver, folder, date, "CreatedWorkBookWithAddedMeasures");

            
            srp.SelectReplenishmentMethodStoreTimeSupply(ReplenishmentMethodStoreTimeSupply);
            srp.EnterMaxTimeSupplyDaysStore(MaxTimeSupplyDaysStore.ToString());
            srp.EnterMinTimeSupplyDaysStore(MinTimeSupplyDaysStore.ToString());
            ss.screen_shot(driver, folder, date, "TimeSupplyValuesEntered");
       
            //click calculator
            tbgp.clickCalculatorButton();

           
            //click Click What If  button.
            srp.clickwhatifConstrainedButton();

            srp.SearchAndFind("Store Available to Plan", 1);
            srp.SearchAndFind(truedate, 1);

            ss.screen_shot(driver, folder, date, "AfterCalculationandWhatIfConstrained");
            String ActualReplenishmentMethod = srp.getReplenishmentMethodStore();
            String ActualMinTimeSupplyDays = srp.getMinTimeSupplyDays();
            String ActualMaxTimeSupplyDays = srp.getMaxTimeSupplyDays();
            //validate Wha If - Rep Method, Max Time supply days, and Min Time supply days
            Assert.IsTrue(ActualReplenishmentMethod.Equals(ReplenishmentMethodStoreTimeSupply), "Actual Replenishment Method: " + ActualReplenishmentMethod + "\nExpected Replenishment Method: " + ReplenishmentMethodStoreTimeSupply);
            Console.WriteLine("Validation Point Passed. Replenishment Method: " + ReplenishmentMethodStoreTimeSupply);
            Assert.IsTrue(ActualMinTimeSupplyDays.Equals(MinTimeSupplyDaysStore.ToString("0.00")), "Actual Min Time Supply Days: " + ActualMinTimeSupplyDays + "\nExpected Min Time Supply Days: " + MinTimeSupplyDaysStore);
            Console.WriteLine("Validation Point Passed. Min Time Supply Days: " + MinTimeSupplyDaysStore);
            Assert.IsTrue(ActualMaxTimeSupplyDays.Equals(MaxTimeSupplyDaysStore.ToString("0.00")), "Max Time Supply Days: " + ActualMaxTimeSupplyDays + "\nExpected Max Time Supply Days: " + MaxTimeSupplyDaysStore);
            Console.WriteLine("Validation Point Passed. Max Time Supply Days: " + MaxTimeSupplyDaysStore);

            //Click logout link
            tbgp.clickLogout();

            fp.WaitForFrameToBeAvailableAndSwitchToIt();
            
            //Click Do not Save
            lpup.DoNotSave();
         
            logout.WaitForLogoutScreen(driver);
            
        }

        [TestMethod]
        public void TS03_09_01_Validation()
        {
            
            folder = folder + "_Validation";

            //Login
            login.successfullLogin(driver);
            ss.screen_shot(driver, folder, date, "AfterLogin");

            //Navigate to worksheet by creating workbook under this path  Analyzing activity
            //> Store Replenishment task and Sales 
            //> Sales, Order, Inventory
            np.NavigateToAndCreateWB_AnalyzingStoreReplenishmentSalesOrdersInventory();

            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //Select any subclass from the list 
            sdonw.SelectDomainName(DomainName);
            ss.screen_shot(driver, folder, date, "Subclass");

            //Click on OK button 
            sdonw.clickOK();


            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //search sku ad, add all associated stores, add all days
            wwp.SearchSKU_AddAllStore_AllDays(sku, folder, date);

            //Long load creating workbook
            wait.WaitForLoadingCreatingWorkbook(driver);


            //wait for workbook to load.
            fp.SwitchToDefaultContent();
            wait.WaitForWorkBookToLoad(driver);
            ss.screen_shot(driver, folder, date, "WorkBookCreated");

            //click sheet
            wp.ClickSheetName("SRP Replenishment Summary (SKU/Store/Day)");
            ss.screen_shot(driver, folder, date, "SRP Replenishment Summary_StoreSkuDay");

            wp.clickRulerAndSelectReplTimeSupply();

            //click Measure
            wp.ClickMeasure();  
           

            //Click and add Demo Stock - Store    
            mp.findThenAddMeasure("Replenishment Method - Store");
            mp.findThenAddMeasure("Max Safety Stock Units (expanded)");
            mp.findThenAddMeasure("Max Safety Stock Units - Store");
            mp.findThenAddMeasure("Max Sellable Quantity - Store");
            mp.findThenAddMeasure("Min Safety Stock Units (expanded)");
            mp.findThenAddMeasure("Min Safety Stock Units - Store");
            mp.findThenAddMeasure("Min Sales Stock - Store");
            mp.findThenAddMeasure("Boundary Stock (expanded) - Store");
            mp.findThenAddMeasure("Boundary Stock - Store");
            mp.findThenAddMeasure("Customer Orders over Review Time - Store");

            mp.findThenAddMeasure("Max Time Supply Days - Store");
            mp.findThenAddMeasure("Min Time Supply Days - Store");
            mp.findThenAddMeasure("Promotion Presentation Stock Factor - Store");
            mp.findThenAddMeasure("Safety Stock Level Factor (expanded) - Store");
            mp.findThenAddMeasure("Safety Stock Level Factor - Store");
            mp.findThenAddMeasure("Time Supply Horizon - Store");


            ss.screen_shot(driver, folder, date, "AddedMeasures");
            //click apply then ok
            mp.clickApply();
            wait.WaitForReady(driver, TimeSpan.FromSeconds(10));
            mp.clickOk();

            //search added measure to take screenshot
            wait.WaitForReady(driver, TimeSpan.FromSeconds(30));
            
            //Search todays date then find first column with editable fields
           String truedate = InputDate;
            
            truedate = srp.CheckIfSelectedDateHasAvailableToPlanAndEditable(truedate);
            srp.SearchAndFind("Store Available to Plan", 1);
            srp.SearchAndFind(truedate, 1);
           
            //String truedate = srp.PositionToFirstColumnWithEditableFields("Store Available to Plan", 1);

            //wait for area with scroll to load
            wp.WaitForAreaWithScrollToLoad();

            ss.screen_shot(driver, folder, date, "CreatedWorkBookWithAddedMeasures");
            
            //Validate what if values
            //Receive Up To Level (What-If) - Store
            //Receipt Point (What-If) - Store
            //Safety Stock (What-If) - Store 
            String[] whatIf = srp.TimeSupplyValidations_Whatif();
            ss.screen_shot(driver, folder, date, "TimeSupplyValidations_Whatif");
            //Validate Safety Stock - Store 
            //Receive Up to Level - Store
            //Receipt Point - Store
            srp.SearchAndFind("Store Available to Plan", 1);
            srp.SearchAndFind(truedate, 1);

            String[] elevated = srp.TimeSupplyValidations_Elevated();
            ss.screen_shot(driver, folder, date, "TimeSupplyValidations_Elevated");

            Assert.IsTrue(whatIf[0].Equals(ReceiveUpToLevel), "Actual Receive Up To Level (What-If) - Store: " + whatIf[0] + "\n Expected Receive Up To Level (What-If) - Store: " + ReceiveUpToLevel);
            Console.WriteLine("Validation Point Passed. Receive Up To Level (What-If) - Store: " + ReceiveUpToLevel);
            Assert.IsTrue(whatIf[1].Equals(ReceiptPoint), "Actual Receipt Point (What-If) - Store: " + whatIf[1] + "\n Expected Receipt Point (What-If) - Store: " + ReceiptPoint);
            Console.WriteLine("Validation Point Passed. Receipt Point (What-If) - Store: " + ReceiptPoint);
            Assert.IsTrue(whatIf[2].Equals(SafetyStock), "Actual Safety Stock (What-If) - Store: " + whatIf[2] + "\n Expected Safety Stock (What-If) - Store: " + SafetyStock);
            Console.WriteLine("Validation Point Passed. Safety Stock (What-If) - Store: " + SafetyStock);

            Assert.IsTrue(elevated[0].Equals(SafetyStock), "Actual Safety Stock - Store: " + elevated[0] + "\n Expected Safety Stock - Store: " + SafetyStock);
            Console.WriteLine("Validation Point Passed. Safety Stock - Store: " + SafetyStock);
            Assert.IsTrue(elevated[1].Equals(ReceiveUpToLevel), "Actual Receive Up to Level - Store: " + elevated[1] + "\n Expected Receive Up to Level - Store: " + ReceiveUpToLevel);
            Console.WriteLine("Validation Point Passed. Receive Up to Level - Store: " + ReceiveUpToLevel);
            Assert.IsTrue(elevated[2].Equals(ReceiptPoint), "Actual Receipt Point - Store: " + elevated[2] + "\n Expected Receipt Point - Store: " + ReceiptPoint);
            Console.WriteLine("Validation Point Passed. Receipt Point - Store: " + ReceiptPoint);

            //Click logout link
            tbgp.clickLogout();

            fp.WaitForFrameToBeAvailableAndSwitchToIt();
            

            //Click Do not Save
            lpup.DoNotSave();

            logout.WaitForLogoutScreen(driver);
            
        }
    }
}
