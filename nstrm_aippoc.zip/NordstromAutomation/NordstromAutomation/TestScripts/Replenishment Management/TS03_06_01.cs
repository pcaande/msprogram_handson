﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NordstromAutomation.Functions;
using NordstromAutomation.TestScripts;
using OpenQA.Selenium;
using NordstromAutomation.Pages;
using System.Collections.Generic;
using OpenQA.Selenium.Support.PageObjects;

namespace NordstromAutomation.TestScripts.Replenishment_Management
{
    /// <summary>
    /// TSC.03.06.01
    /// Validate the Store Replenishment Plan for the active SKU when Replenishment Method 
    /// is Min/Max and On Sale is present date and Off Sale is 3/31/2016.
    /// </summary>
    [TestClass]
    public class TS03_06_01 : TestBase
    {
        
        //Functions
        Click click = new Click();
        Enter enter = new Enter();
        Select select = new Select();
        Validate val = new Validate();
        Wait wait = new Wait();
        ScreenShot ss = new ScreenShot();

        //Pages
        MeasuresPage mp = new MeasuresPage(driver);
        SRPReplenishmentSummary_SKUStoreDay srp = new SRPReplenishmentSummary_SKUStoreDay(driver);
        TopBarGlobalPage tbgp = new TopBarGlobalPage(driver);
        NavigationPage np = new NavigationPage(driver);
        FramesPage fp = new FramesPage(driver);
        SelectDomainOnNewWB sdonw = new SelectDomainOnNewWB(driver);
        WorkbookWizardPage wwp = new WorkbookWizardPage(driver);
        WorkbookPage wp = new WorkbookPage(driver);
        LogoutPopUpPage lpup = new LogoutPopUpPage(driver);
        LogoutPage logout = new LogoutPage();
        LoginPage login = new LoginPage();

        String folder = "TS03_06_01";
        String date = DateTime.Now.ToString("MMddyyyy_hhmm");//MMddyyyy_hhmm

        //TESTSCRIPT
        String DomainName = "global";
        String sku = "3441";// -- (ORIG)91941646 -- (DEV06)1014532779 -- (DEV01)3441 -- (TST05)1004405728 --36018401
        String InputDate = DateTime.Today.ToString("M/dd/yyyy");
        String IncrementPercentStore = "1";
        String MaxStockStore = "50.00";
        String MinStockStore = "15.00";
        String ReplenishmentMethodStore = "Min Max";
        String RecieptPoint = "15.00";

        //VALIDATION: validate if RP,RP$ has leveled up
        String expectedSafetyStockStore = "15.00";
        String expectedReceiveUptoLevelStore = "50.00";
        String expectedReceiptPointStore = "15.00";
        Decimal SKUPrice = 3.97m;           

        [TestMethod]
        public void TS03_06_01_TestScript()
        {
           
            //Login
            login.successfullLogin(driver);
            ss.screen_shot(driver, folder, date, "AfterLogin");

            //Navigate to worksheet by creating workbook under this path  Analyzing activity
            //> Store Replenishment task and Sales 
            //> Sales, Order, Inventory
            np.NavigateToAndCreateWB_AnalyzingStoreReplenishmentSalesOrdersInventory();
            
            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //Select any subclass from the list 
            sdonw.SelectDomainName(DomainName);
            ss.screen_shot(driver, folder, date, "Subclass");

            //Click on OK button 
            sdonw.clickOK();


            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //search sku ad, add all associated stores, add all days
            wwp.SearchSKU_AddAllStore_AllDays(sku, folder, date);

            //Long load creating workbook
            wait.WaitForLoadingCreatingWorkbook(driver);


            //wait for workbook to load.
            fp.SwitchToDefaultContent();
            wait.WaitForWorkBookToLoad(driver);
            ss.screen_shot(driver, folder, date, "WorkBookCreated");

            //click sheet
            wp.ClickSheetName("SRP Replenishment Summary (SKU/Store/Day)");
            ss.screen_shot(driver, folder, date, "SRP Replenishment Summary_StoreSkuDay");

            wp.clickRulerAndSelectReplMinMax();

            //click Measure
            wp.ClickMeasure();

            //Search and Add Measure
            mp.findThenAddMeasure("Increment Percent - Store");
            mp.findThenAddMeasure("Max Stock - Store");
            mp.findThenAddMeasure("Min Stock - Store");
            mp.findThenAddMeasure("Replenishment Method - Store");
            mp.findThenAddMeasure("Max Safety Stock Units (expanded)");
            mp.findThenAddMeasure("Max Safety Stock Units - Store");
            mp.findThenAddMeasure("Max Sellable Quantity - Store");
            mp.findThenAddMeasure("Min Safety Stock Units (expanded)");
            mp.findThenAddMeasure("Min Safety Stock Units - Store");
            mp.findThenAddMeasure("Min Sales Stock - Store");
            mp.findThenAddMeasure("Boundary Stock (expanded) - Store");
            mp.findThenAddMeasure("Boundary Stock - Store");
            mp.findThenAddMeasure("Customer Orders over Review Time - Store");
            mp.findThenAddMeasure("Demo Stock (expanded) - Store");
            mp.findThenAddMeasure("Demo Stock - Store");
            mp.findThenAddMeasure("Supplier Compliance Safety Stock - Store");

            ss.screen_shot(driver, folder, date, "AddedMeasures");
            //click apply then ok
            mp.clickApply();
            wait.WaitForReady(driver, TimeSpan.FromSeconds(10));
            mp.clickOk();

            //wait for area with scroll to load
            wp.WaitForAreaWithScrollToLoad();
            
            ss.screen_shot(driver, folder, date, "CreatedWorkBookWithAddedMeasures");

            String truedate = InputDate;
            
            truedate = srp.CheckIfSelectedDateHasAvailableToPlanAndEditable(truedate);
            srp.SearchAndFind("Min Stock - Store", 2);
            srp.SearchAndFind(truedate, 1); //MM/dd/yyyy
            
            
            wait.WaitForReady(driver, TimeSpan.FromSeconds(10));
            //enter values
            srp.EnterIncrementPercentStore(IncrementPercentStore);
            srp.EnterMaxStockStore(MaxStockStore);
            srp.EnterMinStockStore(MinStockStore);
            srp.SelectReplenishmentMethodStore(ReplenishmentMethodStore);

            ss.screen_shot(driver, folder, date, "MinMaxValuesEntered");

            //click calculator
            tbgp.clickCalculatorButton();

            srp.SearchAndFind("Receive Up To Level", 2);
            srp.SearchAndFind(truedate, 1);

            //validate Wha If - SS,RP, and RUTL
            Assert.IsTrue(srp.get_RUTL_Whatif().Equals(MaxStockStore), "RUTL does not equal to " + MaxStockStore);
            Console.WriteLine("Recieve Up To Level What If Passed! Value:  " + MaxStockStore);
            Assert.IsTrue(srp.get_RP_Whatif().Equals(RecieptPoint), "Reciept Point does not equal to " + RecieptPoint);
            Console.WriteLine("Reciept Point What If Passed! Value:  " + RecieptPoint);
            Assert.IsTrue(srp.get_SS_Whatif().Equals(MinStockStore), "SS does not equal to " + MinStockStore);
            Console.WriteLine("Safety Stock What If Passed! Value:  " + MinStockStore);

            //click Click What If  button.
            srp.clickwhatifConstrainedButton();
            
            srp.SearchAndFind("Replenishment Method", 1);
            
            ss.screen_shot(driver, folder, date, "AfterCalculationandWhatIfConstrained");

            //Click logout link
            tbgp.clickLogout();

            fp.WaitForFrameToBeAvailableAndSwitchToIt();
            
            //Click Do not Save
            lpup.DoNotSave();

            logout.WaitForLogoutScreen(driver);
            
        }

        [TestMethod]
        public void TS03_06_01_Validation()
        {

            String expectedReceiptPlanDollarStore = (SKUPrice * decimal.Parse(expectedReceiveUptoLevelStore)).ToString();
            folder = folder + "_Validation";

            //Login
            login.successfullLogin(driver);
            ss.screen_shot(driver, folder, date, "AfterLogin");

            //Navigate to worksheet by creating workbook under this path  Analyzing activity
            //> Store Replenishment task and Sales 
            //> Sales, Order, Inventory
            np.NavigateToAndCreateWB_AnalyzingStoreReplenishmentSalesOrdersInventory();

            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //Select any subclass from the list 
            sdonw.SelectDomainName(DomainName);
            ss.screen_shot(driver, folder, date, "Subclass");

            //Click on OK button 
            sdonw.clickOK();


            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //search sku ad, add all associated stores, add all days
            wwp.SearchSKU_AddAllStore_AllDays(sku, folder, date);

            //Long load creating workbook
            wait.WaitForLoadingCreatingWorkbook(driver);


            //wait for workbook to load.
            fp.SwitchToDefaultContent();
            wait.WaitForWorkBookToLoad(driver);
            ss.screen_shot(driver, folder, date, "WorkBookCreated");

            //click sheet
            wp.ClickSheetName("SRP Replenishment Summary (SKU/Store/Day)");
            ss.screen_shot(driver, folder, date, "SRP Replenishment Summary_StoreSkuDay");

            wp.clickRulerAndSelectReplMinMax();

            //click Measure
            wp.ClickMeasure();
            

            //Click and add Demo Stock - Store
            mp.findThenAddMeasure("Increment Percent - Store");
            mp.findThenAddMeasure("Max Stock - Store");
            mp.findThenAddMeasure("Min Stock - Store");
            mp.findThenAddMeasure("Replenishment Method - Store");
            mp.findThenAddMeasure("Max Safety Stock Units (expanded)");
            mp.findThenAddMeasure("Max Safety Stock Units - Store");
            mp.findThenAddMeasure("Max Sellable Quantity - Store");
            mp.findThenAddMeasure("Min Safety Stock Units (expanded)");
            mp.findThenAddMeasure("Min Safety Stock Units - Store");
            mp.findThenAddMeasure("Min Sales Stock - Store");
            mp.findThenAddMeasure("Boundary Stock (expanded) - Store");
            mp.findThenAddMeasure("Boundary Stock - Store");
            mp.findThenAddMeasure("Customer Orders over Review Time - Store");
            mp.findThenAddMeasure("Demo Stock (expanded) - Store");
            mp.findThenAddMeasure("Demo Stock - Store");
            mp.findThenAddMeasure("Supplier Compliance Safety Stock - Store");
           
            ss.screen_shot(driver, folder, date, "AddedMeasures");
            //click apply then ok
            mp.clickApply();
            wait.WaitForReady(driver, TimeSpan.FromSeconds(10));
            mp.clickOk();
            wait.WaitForReady(driver, TimeSpan.FromSeconds(30));

            String truedate = InputDate;
            truedate = srp.CheckIfSelectedDateHasAvailableToPlanAndEditable(truedate);
            srp.SearchAndFind("Store Available to Plan", 1);
            srp.SearchAndFind(truedate, 1);
            
            wp.WaitForAreaWithScrollToLoad();
            
            //validate what if RP, RP $
            String[] actualValues = srp.MinMaxValidations();
            decimal ProjectedInventory = decimal.Parse(expectedReceiveUptoLevelStore) - decimal.Parse(actualValues[7]);
            Console.WriteLine("expectedReceiveUptoLevelStore: " + decimal.Parse(expectedReceiveUptoLevelStore));
            Console.WriteLine("actualValues[7]: " + decimal.Parse(actualValues[7]));
            Console.WriteLine("ProjectedInventory: " + ProjectedInventory);
            String expectedReceiptPlanWhatIfStore = Math.Round(ProjectedInventory, 0).ToString("0.00");
            Console.WriteLine("Expected Receipt Plan: " + expectedReceiptPlanWhatIfStore);
            expectedReceiptPlanDollarStore = (SKUPrice * decimal.Parse(expectedReceiptPlanWhatIfStore)).ToString("0.00");
            Console.WriteLine("Expected Receipt Plan Dollar: " + expectedReceiptPlanDollarStore);
            Assert.IsTrue(actualValues[0].Equals(expectedReceiptPlanWhatIfStore), "Receipt Plan (What-If) - Store: " + actualValues[0]);
            Console.WriteLine("Validation Point Passed. Receipt Plan (What-If) - Store: " + expectedReceiptPlanWhatIfStore);
            Assert.IsTrue(actualValues[1].Equals(expectedReceiptPlanDollarStore), "Receive Up To Level (What-If) - Store: " + actualValues[1]);
            Console.WriteLine("Validation Point Passed. Receive Up To Level (What-If) - Store: " + expectedReceiptPlanDollarStore);
 
            //validate if RP,RP$ has leveled up
            Assert.IsTrue(actualValues[2].Equals(expectedSafetyStockStore), "Safety Stock - Store: " + actualValues[2]);
            Console.WriteLine("Validation Point Passed. Safety Stock - Store: " + expectedSafetyStockStore);
            Assert.IsTrue(actualValues[3].Equals(expectedReceiptPlanWhatIfStore), "Reciept Plan - Store: " + actualValues[3]);
            Console.WriteLine("Validation Point Passed. Reciept Plan - Store: " + expectedReceiptPlanWhatIfStore);
            Assert.IsTrue(actualValues[4].Equals(expectedReceiptPlanDollarStore), "Receipt Plan $ - Store: " + actualValues[4]);
            Console.WriteLine("Validation Point Passed. Reciept Plan $ - Store: " + expectedReceiptPlanDollarStore);
            Assert.IsTrue(actualValues[5].Equals(expectedReceiveUptoLevelStore), "Receive Up to Level - Store: " + actualValues[5]);
            Console.WriteLine("Validation Point Passed. Receive Up to Level - Store: " + expectedReceiveUptoLevelStore);
            Assert.IsTrue(actualValues[6].Equals(expectedReceiptPointStore), "Receipt Point - Store: " + actualValues[6]);
            Console.WriteLine("Validation Point Passed. Receipt Point - Store: " + expectedReceiptPointStore);

            ss.screen_shot(driver, folder, date, "MinMaxElevatedValues");

            //Click logout link
            tbgp.clickLogout();


            fp.WaitForFrameToBeAvailableAndSwitchToIt();
            
            //Click Do not Save
            lpup.DoNotSave();          
            logout.WaitForLogoutScreen(driver);
        }

    }
}
