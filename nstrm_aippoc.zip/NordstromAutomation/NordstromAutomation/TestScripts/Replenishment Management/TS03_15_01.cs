﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using NordstromAutomation.Functions;
using NordstromAutomation.Pages;

namespace NordstromAutomation.TestScripts.Replenishment_Management
{
    /// <summary>
    /// Validate the Store Replenishment Plan for the active SKU when Replenishment Method 
    /// No Safety Stock and On Sale is present date and Off Sale is 3/31/2016.
    /// </summary>
    [TestClass]
    public class TS03_15_01 : TestBase
    {

        //Functions
        Click click = new Click();
        Enter enter = new Enter();
        Select select = new Select();
        Validate val = new Validate();
        Wait wait = new Wait();
        ScreenShot ss = new ScreenShot();

        //Pages
        MeasuresPage mp = new MeasuresPage(driver);
        SRPReplenishmentSummary_SKUStoreDay srp = new SRPReplenishmentSummary_SKUStoreDay(driver);
        TopBarGlobalPage tbgp = new TopBarGlobalPage(driver);
        NavigationPage np = new NavigationPage(driver);
        FramesPage fp = new FramesPage(driver);
        SelectDomainOnNewWB sdonw = new SelectDomainOnNewWB(driver);
        WorkbookWizardPage wwp = new WorkbookWizardPage(driver);
        WorkbookPage wp = new WorkbookPage(driver);
        LogoutPopUpPage lpup = new LogoutPopUpPage(driver);
        LogoutPage logout = new LogoutPage();
        LoginPage login = new LoginPage();

        String folder = "TS03_15_01";
        String date = DateTime.Now.ToString("MMddyyyy_hhmm");

        //TESTSCRIPT
        String DomainName = "global";
        String sku = "3441"; //91941646
        String InputDate = DateTime.Today.ToString("M/dd/yyyy");
        String ReplenishmentMethodStore = "No Safety Stock";

        //VALIDATION: validate if RP,RP$ has leveled up
        String expectedSafetyStockStore = "0.00";
        String expectedReceiveUptoLevelStore = "42.86";
        String expectedReceiptPointStore = "42.86";
        String expectedMinSalesStock = "100.00";

        

        [TestMethod]
        public void TS03_15_01_TestScript()
        {

            //Login
            login.successfullLogin(driver);
            ss.screen_shot(driver, folder, date, "AfterLogin");

            //Navigate to worksheet by creating workbook under this path  Analyzing activity
            //> Store Replenishment task and Sales 
            //> Sales, Order, Inventory
            np.NavigateToAndCreateWB_AnalyzingStoreReplenishmentSalesOrdersInventory();

            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //Select any subclass from the list 
            sdonw.SelectDomainName(DomainName);
            ss.screen_shot(driver, folder, date, "Subclass");

            //Click on OK button 
            sdonw.clickOK();


            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //search sku ad, add all associated stores, add all days
            wwp.SearchSKU_AddAllStore_AllDays(sku, folder, date);

            //Long load creating workbook
            wait.WaitForLoadingCreatingWorkbook(driver);


            //wait for workbook to load.
            fp.SwitchToDefaultContent();
            wait.WaitForWorkBookToLoad(driver);
            ss.screen_shot(driver, folder, date, "WorkBookCreated");

            //click sheet
            wp.ClickSheetName("SRP Replenishment Summary (SKU/Store/Day)");
            ss.screen_shot(driver, folder, date, "SRP Replenishment Summary_StoreSkuDay");            

            //click Measure
            wp.ClickMeasure();

            

            //Click and add Demo Stock - Store    
            mp.findThenAddMeasure("Replenishment Method - Store");
            mp.findThenAddMeasure("Max Safety Stock Units (expanded)");
            mp.findThenAddMeasure("Max Safety Stock Units - Store");
            mp.findThenAddMeasure("Max Sellable Quantity - Store");
            mp.findThenAddMeasure("Min Safety Stock Units (expanded)");
            mp.findThenAddMeasure("Min Safety Stock Units - Store");
            mp.findThenAddMeasure("Min Sales Stock - Store");
            mp.findThenAddMeasure("Boundary Stock (expanded) - Store");
            mp.findThenAddMeasure("Boundary Stock - Store");
            mp.findThenAddMeasure("Customer Orders over Review Time - Store");

            mp.findThenAddMeasure("Max Time Supply Days - Store");
            mp.findThenAddMeasure("Min Time Supply Days - Store");
            mp.findThenAddMeasure("Promotion Presentation Stock Factor - Store");
            mp.findThenAddMeasure("Safety Stock Level Factor (expanded) - Store");
            mp.findThenAddMeasure("Safety Stock Level Factor - Store");
            mp.findThenAddMeasure("Time Supply Horizon - Store");

            ss.screen_shot(driver, folder, date, "AddedMeasures");
            //click apply then ok
            mp.clickApply();
            wait.WaitForReady(driver, TimeSpan.FromSeconds(10));
            mp.clickOk();

            //wait for area with scroll to load
            wait.WaitForVisbilityBy(driver, By.XPath(".//*[substring(@id, string-length(@id) - string-length('DatabodyScroller11') +1) = 'DatabodyScroller11']"));

            ss.screen_shot(driver, folder, date, "CreatedWorkBookWithAddedMeasures");

            /*String truedate = DateTime.Today.ToString("MM/dd/yyyy");
            if (!srp.IsTodaysColumnEditableWithIncrementValue(450))
            {
                truedate = srp.PositionToFirstColumnWithEditableFields("Replenishment Method", 2, 450);
            }*/

            String truedate = InputDate;

            truedate = srp.CheckIfSelectedDateHasAvailableToPlanAndEditableWithIncrementValue(truedate, 450);
            srp.SearchAndFind("Replenishment Method", 2);
            srp.SearchAndFind(truedate, 1);

            //Select Replenishment Method
            srp.SelectDropDownFieldFromTopWithIncrement(ReplenishmentMethodStore, 870);

            ss.screen_shot(driver, folder, date, "NoSafetyStockValuesEntered");
            //click calculator
            tbgp.clickCalculatorButton();

            srp.SearchAndFind("Receive Up To Level", 2);
            srp.SearchAndFind(truedate, 1);

            //validate Wha If - SS,RP, and RUTL
            Assert.IsTrue(srp.getFieldValueFromBottomWithIncrement("Actual RUTL", 480).Equals(expectedReceiveUptoLevelStore), "RUTL does not equal to " + expectedReceiveUptoLevelStore);
            Console.WriteLine("Recieve Up To Level What If Passed! Value:  " + expectedReceiveUptoLevelStore);
            Assert.IsTrue(srp.getFieldValueFromBottomWithIncrement("Actual Reciept Point", 450).Equals(expectedReceiptPointStore), "Reciept Point does not equal to " + expectedReceiptPointStore);
            Console.WriteLine("Reciept Point What If Passed! Value:  " + expectedReceiptPointStore);
            Assert.IsTrue(srp.getFieldValueFromBottomWithIncrement("Actual SS", 420).Equals(expectedSafetyStockStore), "SS does not equal to " + expectedSafetyStockStore);
            Console.WriteLine("Safety Stock What If Passed! Value:  " + expectedSafetyStockStore);
            

            //click Click What If  button.
            srp.clickwhatifConstrainedButton();

            srp.SearchAndFind("Replenishment Method", 1);

            ss.screen_shot(driver, folder, date, "AfterCalculationandWhatIfConstrained");

            //Click logout link
            tbgp.clickLogout();

            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //Click Do not Save
            lpup.DoNotSave();

            logout.WaitForLogoutScreen(driver);
            

        }

        [TestMethod]
        public void TS03_15_01_Validation()
        {
            
            //String expectedReceiptPlanDollarStore = (SKUPrice * decimal.Parse(expectedReceiveUptoLevelStore)).ToString();
            folder = folder + "_Validation";
            //Login
            login.successfullLogin(driver);
            ss.screen_shot(driver, folder, date, "AfterLogin");

            //Navigate to worksheet by creating workbook under this path  Analyzing activity
            //> Store Replenishment task and Sales 
            //> Sales, Order, Inventory
            np.NavigateToAndCreateWB_AnalyzingStoreReplenishmentSalesOrdersInventory();

            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //Select any subclass from the list 
            sdonw.SelectDomainName(DomainName);
            ss.screen_shot(driver, folder, date, "Subclass");

            //Click on OK button 
            sdonw.clickOK();


            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //search sku ad, add all associated stores, add all days
            wwp.SearchSKU_AddAllStore_AllDays(sku, folder, date);

            //Long load creating workbook
            wait.WaitForLoadingCreatingWorkbook(driver);


            //wait for workbook to load.
            fp.SwitchToDefaultContent();
            wait.WaitForWorkBookToLoad(driver);
            ss.screen_shot(driver, folder, date, "WorkBookCreated");

            //click sheet
            wp.ClickSheetName("SRP Replenishment Summary (SKU/Store/Day)");
            ss.screen_shot(driver, folder, date, "SRP Replenishment Summary_StoreSkuDay");

            //click Measure
            wp.ClickMeasure();

            /*
              * Add the following measures in Workbook:
                 - Replenishment Method - Store /
                 - Max Safety Stock Units (expanded) /
                 - Max Safety Stock Units - Store /
                 - Max Sellable Quantity - Store /
                 - Min Safety Stock Units (expanded) /
                 - Min Safety Stock Units - Store /
                 - Min Sales Stock - Store /
                 - Boundary Stock (expanded) - Store /
                 - Boundary Stock - Store /
                 - Customer Orders over Review Time - Store /
                 - Max Time Supply Days - Store =======
                 - Min Time Supply Days - Store
                 - Promotion Presentation Stock Factor - Store
                 - Safety Stock Level Factor (expanded) - Store
                 - Safety Stock Level Factor - Store
                 - Time Supply Horizon - Store
              */

            //Click and add Demo Stock - Store    
            mp.findThenAddMeasure("Replenishment Method - Store");
            mp.findThenAddMeasure("Max Safety Stock Units (expanded)");
            mp.findThenAddMeasure("Max Safety Stock Units - Store");
            mp.findThenAddMeasure("Max Sellable Quantity - Store");
            mp.findThenAddMeasure("Min Safety Stock Units (expanded)");
            mp.findThenAddMeasure("Min Safety Stock Units - Store");
            mp.findThenAddMeasure("Min Sales Stock - Store");
            mp.findThenAddMeasure("Boundary Stock (expanded) - Store");
            mp.findThenAddMeasure("Boundary Stock - Store");
            mp.findThenAddMeasure("Customer Orders over Review Time - Store");

            mp.findThenAddMeasure("Max Time Supply Days - Store");
            mp.findThenAddMeasure("Min Time Supply Days - Store");
            mp.findThenAddMeasure("Promotion Presentation Stock Factor - Store");
            mp.findThenAddMeasure("Safety Stock Level Factor (expanded) - Store");
            mp.findThenAddMeasure("Safety Stock Level Factor - Store");
            mp.findThenAddMeasure("Time Supply Horizon - Store");

            ss.screen_shot(driver, folder, date, "AddedMeasures");
            //click apply then ok
            mp.clickApply();
            wait.WaitForReady(driver, TimeSpan.FromSeconds(10));
            mp.clickOk();
            wait.WaitForReady(driver, TimeSpan.FromSeconds(30));

            String truedate = InputDate;

            truedate = srp.CheckIfSelectedDateHasAvailableToPlanAndEditableWithIncrementValue(truedate, 450);
            srp.SearchAndFind("Replenishment Method", 2);
            srp.SearchAndFind(truedate, 1);
            

            wait.WaitForVisbilityBy(driver, By.XPath(".//*[substring(@id, string-length(@id) - string-length('DatabodyScroller11') +1) = 'DatabodyScroller11']"));

            //Assert.Fail();

            Assert.IsTrue(srp.getFieldValueFromTopWithIncrement(360).Equals(expectedReceiveUptoLevelStore), "Recieve Up To Level - Store does not equal to " + expectedReceiveUptoLevelStore);
            Console.WriteLine("Recieve Up To Level - Store Passed! Value:  " + expectedReceiveUptoLevelStore);
            Assert.IsTrue(srp.getFieldValueFromTopWithIncrement(390).Equals(expectedReceiptPointStore), "Receipt Point - Store does not equal to " + expectedReceiptPointStore);
            Console.WriteLine("Receipt Point - Store Passed! Value:  " + expectedReceiptPointStore);
            
            ss.screen_shot(driver, folder, date, "RUTL_RP_ElevatedValues");

            srp.SearchAndFind("Min Sales Stock - Store", 1);
            srp.SearchAndFind(truedate, 1);
            //validate MSS
            Assert.IsTrue(srp.getFieldValueFromBottomWithIncrement("Actual Min Sales Stock", 210).Equals(expectedMinSalesStock), "Min Sales Stock - Store does not equal to " + expectedMinSalesStock);
            Console.WriteLine("Min Sales Stock - Store Passed! Value:  " + expectedMinSalesStock);

            ss.screen_shot(driver, folder, date, "MSS_ElevatedValues");

            //Click logout link
            tbgp.clickLogout();

            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //Click Do not Save
            lpup.DoNotSave();

            logout.WaitForLogoutScreen(driver);
            
        }
    }
}
