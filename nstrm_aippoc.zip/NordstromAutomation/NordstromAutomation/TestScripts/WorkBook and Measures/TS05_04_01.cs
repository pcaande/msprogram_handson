﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NordstromAutomation.Functions;
using OpenQA.Selenium;
using NordstromAutomation.Pages;

namespace NordstromAutomation.TestScripts.WorkBook_and_Measures
{
    /// <summary>
    /// 
    /// TS.05.01_Validate that all base AIP measure properties 
    /// and values in Analyzing > Store Replenishment > Sales, Orders & Inventory > SRP Replenishment Summary (SKU/Store/Day) View are correct.
    /// 
    /// "Generate Analyzing > Store Replenishment > Sales, Orders & Inventory
    /// > SRP Replenishment Summary (SKU/Store/Day) View and 
    /// validate that all user entered base AIP measure properties 
    /// are correct.
    /// 
    /// </summary>
    [TestClass]
    public class TS05_04_01 : TestBase
    {
              
        //Functions
        Click click = new Click();
        Enter enter = new Enter();
        Select select = new Select();
        Validate val = new Validate();
        Wait wait = new Wait();
        ScreenShot ss = new ScreenShot();

        //Pages
        MeasuresPage mp = new MeasuresPage(driver);
        SRPReplenishmentSummary_SKUStoreDay srp = new SRPReplenishmentSummary_SKUStoreDay(driver);
        TopBarGlobalPage tbgp = new TopBarGlobalPage(driver);
        NavigationPage np = new NavigationPage(driver);
        FramesPage fp = new FramesPage(driver);
        SelectDomainOnNewWB sdonw = new SelectDomainOnNewWB(driver);
        WorkbookWizardPage wwp = new WorkbookWizardPage(driver);
        WorkbookPage wp = new WorkbookPage(driver);
        LogoutPopUpPage lpup = new LogoutPopUpPage(driver);
        LogoutPage logout = new LogoutPage();
        LoginPage login = new LoginPage();

        String folder = "TS05_04_01";
        String date = DateTime.Now.ToString("MMddyyyy_hhmm");
        String DomainName = "global";

       
        [TestMethod]
        public void TS05_04_01_TestScript()
        {

            login.successfullLogin(driver);
            ss.screen_shot(driver, folder, date, "AfterLogin");

            //Navigate to worksheet by creating workbook under this path  Analyzing activity
            //> Warehouse Replenishment 
            //> Order, Inventory
            np.NavigateToAndCreateWB_AnalyzingWareHouseReplenishmentOrdersInventory();

            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //Select any subclass from the list 
            sdonw.SelectDomainName(DomainName);
            ss.screen_shot(driver, folder, date, "Subclass");

            //Click on OK button 
            sdonw.clickOK();


            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //search sku ad, add all associated stores, add all days
            wwp.AddAllSKU_AllDays(folder, date);

            //Long load creating workbook
            wait.WaitForLoadingCreatingWorkbook(driver);


            //wait for workbook to load.
            fp.SwitchToDefaultContent();
            wait.WaitForWorkBookToLoad(driver);
            ss.screen_shot(driver, folder, date, "WorkBookCreated");

            //click sheet
            wp.ClickSheetName("SPQ Analysis");
            ss.screen_shot(driver, folder, date, "SPQ Analysis");

            //click Measure
            wp.ClickMeasure();

            
            /*
             * Add the following measures in Workbook:
                : Demo Stock - Store
                : Percent of Pallet - Store
                : Promotion Presentation Stock Override Flag - Store
                : Promotion Presentation Stock Pre Factor - Store
                : Rounding Method - Store
                : Rounding Threshold - Store
                : Shelf Capacity - Store
                : Shelf Capacity Flag - Store
                : User Specified Presentation Stock - Store
             */

            //Click and add Demo Stock - Store
            mp.findThenAddMeasur_SPQAnalysis("SPQ Commitment Type Exception");
            mp.findThenAddMeasur_SPQAnalysis("SPQ Order Commit Quantity");
            
            
            ss.screen_shot(driver, folder, date, "AddedMeasures");
            //click apply then ok
            mp.clickApply_SPQAnalysis();
            wait.WaitForReady(driver, TimeSpan.FromSeconds(10));
            mp.clickOk_SPQAnalysis();

            //search added measure to take screenshot
            wait.WaitForReady(driver, TimeSpan.FromSeconds(30));
            srp.Search(DateTime.Today.ToString("MM/dd/yyyy"));
            srp.FindNext();

            wait.WaitForReady(driver, TimeSpan.FromSeconds(30));
            srp.Search("SPQ Commitment Type Exception");
            srp.FindNext();

            //wait for area with scroll to load
            wp.WaitForAreaWithScrollToLoad();
            

            ss.screen_shot(driver, folder, date, "CreatedWorkBookWithAddedMeasures");


            //Click logout link
            tbgp.clickLogout();

            fp.WaitForFrameToBeAvailableAndSwitchToIt();
            

            //Click Do not Save
            lpup.DoNotSave();

            logout.WaitForLogoutScreen(driver);
            

        }
    }
}
