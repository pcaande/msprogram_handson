﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using NUnit.Framework;
using SikuliSharp;
using SikuliModule;
using System.IO;
using System.Reflection;
using NordstromAutomation.Functions;
using NordstromAutomation.Modules;

namespace NordstromAutomation.TestScripts.PoC_Scripts.DM_Data_Setup
{
    [TestClass]
    public class Warehouse_Chamber
    {
        IWebDriver driver = new InternetExplorerDriver();
        Click click = new Click();
        Enter enter = new Enter();
        ScreenShot ss = new ScreenShot();
       
        
        [TestMethod]
        public void Warehouse_Chamber_Method()
        {
            //Launch IE to AIP Online User Console
            driver.Navigate().GoToUrl("http://y0319t1752:8101/aip14/servlet/rfpservlet/rfp_enter");
            driver.Manage().Window.Maximize();

            //Enter Login details and click login
            enter.enterById(driver, "username", "A8LL");
            enter.enterById(driver, "password", "automationtest");
            click.clickByName(driver, "Submit");

            //click 
            click.clickByXpath(driver, ".//*[@href='/aip14/servlet/rfpservlet/rfp_enter']");

            /*
             *The Test Data below needs to be unique per execution run 
             */
            String Chambername_data = "W1850 - W185 Chamber";
            String Shortcode_data = "39";
            String chambervalue = "New";
            String folder = "Warehouse_Chamber";
            String date = DateTime.Now.ToString("MMddyyyy_hhmm");
            String loadingStartPage = @"C:\Users\A8LL\Documents\Visual Studio 2013\Projects\NordstromAutomation\ObjectImages\Login\";
            String WarehouseChamberImagePath = @"C:\Users\A8LL\Documents\Visual Studio 2013\Projects\NordstromAutomation\ObjectImages\WHChmb\";

            using (var session = Sikuli.CreateSession())
            {
                
                //Login
                var DMStart = Patterns.FromFile(loadingStartPage+"DMStart.PNG", 0.9f);
                var javaload = Patterns.FromFile(loadingStartPage+"JavaLoading.PNG", 0.9f);

                
                /*
                 * Java pop up was removed through the java configure console.
                 * There is another one time pop-up though that you need to handle or else manually press run before running the script first
                 */
                
                //wait for java loading screen
                //SikuliAction.Click(@"C:\Users\A8LL\Documents\Visual Studio 2013\Projects\NordstromAutomation\ObjectImages\Login\JavaLoading.PNG");
                session.WaitVanish(javaload, 120f);
        
                //click start for DM
                
                session.Wait(DMStart, 10f);
                System.Threading.Thread.Sleep(TimeSpan.FromSeconds(3));
                //SikuliAction.Hover(@"C:\Users\A8LL\Documents\Visual Studio 2013\Projects\NordstromAutomation\ObjectImages\Login\DMStart.PNG");
                //Hover();
                session.Click(DMStart, new Point(0, 21), 120f);
                session.WaitVanish(DMStart, 30f);
                //Go to Warehouse > Core data > 
                //Scheduling Location Maintenance. 

                //WHChmb
                var SchedulingLocationMaintenance = Patterns.FromFile(WarehouseChamberImagePath+"SchedulingLocationMaintenance.PNG", 0.9f);
                var W1850185INACTVRSDC299 = Patterns.FromFile(WarehouseChamberImagePath+"W185 - 0185 INACTV - RS DC299.PNG", 0.9f);
              
                session.Wait(SchedulingLocationMaintenance, 10f);
                System.Threading.Thread.Sleep(TimeSpan.FromSeconds(3));
                //SikuliAction.Hover(WarehouseChamberImagePath + "SchedulingLocationMaintenance.PNG");
                session.Click(SchedulingLocationMaintenance, 10f);
                //SikuliAction.Hover(WarehouseChamberImagePath + "W185 - 0185 INACTV - RS DC299.PNG");
                session.Click(W1850185INACTVRSDC299, 10f);
                
                //Click Create Chamber and supply the details (non-existing) Click Save.
                var CreateChamber = Patterns.FromFile(WarehouseChamberImagePath+"Create Chamber.PNG", 0.9f);
                var ChamberName = Patterns.FromFile(WarehouseChamberImagePath+"Chamber Name.PNG", 0.9f);
                
                session.Wait(CreateChamber, 10f);
                System.Threading.Thread.Sleep(TimeSpan.FromSeconds(1));
                //SikuliAction.Hover(WarehouseChamberImagePath + "Create Chamber.PNG");
                session.Click(CreateChamber, 10f);
                
                //Enter Chamber Name
                session.Wait(ChamberName, 10f);
                System.Threading.Thread.Sleep(TimeSpan.FromSeconds(1));
                //SikuliAction.Hover(WarehouseChamberImagePath + "Create Name.PNG");
                session.Click(ChamberName, 10f);
                session.Type(Chambername_data);//chamber name needs to be unique

                //Enter Short Code
                var ShortCode = Patterns.FromFile(WarehouseChamberImagePath+"Short Code.PNG", 0.9f);
                session.Wait(ShortCode, 10f);
                System.Threading.Thread.Sleep(TimeSpan.FromSeconds(1));
                //SikuliAction.Hover(WarehouseChamberImagePath + "Short Code.PNG");
                session.Click(ShortCode, 10f);
                session.Type(Shortcode_data);//short code has to be unique.

                ss.screenshotpranas(folder, date, "CreateChamber");                

                //click save
                var save = Patterns.FromFile(WarehouseChamberImagePath+"Save.PNG", 0.9f);
                session.Wait(save, 5f);
                //SikuliAction.Hover(WarehouseChamberImagePath + "Save.PNG");
                session.Click(save, 10f);
                //session.WaitVanish(save, 10f);
                //ErrorShortCodeNotUnique
                var ErrorShortCodeNotUnique = Patterns.FromFile(WarehouseChamberImagePath+"ErrorShortCodeNotUnique.PNG", 0.9f);

                //try
                //{
                System.Threading.Thread.Sleep(TimeSpan.FromSeconds(3));
                if (session.Exists(ErrorShortCodeNotUnique))
                {
                    NUnit.Framework.Assert.Fail("Short Code Is not Unique!");

                }
               // }catch(TimeoutException e){
               //     Console.WriteLine("Chamber sucessfuly created!");
               // }

                var warning1_ok = Patterns.FromFile(WarehouseChamberImagePath+"warning1_ok.PNG", 0.9f);

                //session.Click(warning1_ok, 10f);
                /*
                 * Code to handle pop up here
                 * */

               /* try
                {
                    session.Click(warning1_ok, 10f);
                }catch(TimeoutException e){
                    Console.WriteLine("Warning message after save chamber not detected!");
                }*/
                //The warning message needs to be retaken. It is not unique enough.
                /*if (session.Exists(warning1_ok))
                {
                    session.Click(warning1_ok, 5f);
                    Console.WriteLine("Create Chamber warning detected");
                }*/
                
                
                //click ok on are you sure pop up
                var areyousureyouwanttosave_ok = Patterns.FromFile(WarehouseChamberImagePath+"Are you sure you want to save.PNG", 0.9f);
                
                session.Wait(areyousureyouwanttosave_ok,5f);
                //SikuliAction.Hover(WarehouseChamberImagePath + "Are you sure you want to save.PNG");
                session.Click(areyousureyouwanttosave_ok, new Point(-27, 10), 10f);


                //click ok on confirm pop up. "Your save was successful"
                var confirmpopup = Patterns.FromFile(WarehouseChamberImagePath+"confirmpopup.PNG", 0.9f);
          
                session.Wait(confirmpopup, 10f);
                //SikuliAction.Hover(WarehouseChamberImagePath + "confirmpopup.PNG");
                session.Click(confirmpopup, new Point(-5, 10), 5f);

                //click on add sku type
                var addskutype = Patterns.FromFile(WarehouseChamberImagePath+"Add SKU Type.PNG", 0.9f);
          
                session.Wait(addskutype, 10f);
                //SikuliAction.Hover(WarehouseChamberImagePath + "Add SKU Type.PNG");
                session.Click(addskutype, 10f);

                //enter details
                var stocklessindicatorcheckbox = Patterns.FromFile(WarehouseChamberImagePath+"stocklessindicatorcheckbox.PNG", 0.9f);
      
                session.Wait(stocklessindicatorcheckbox, 10f);
                var skudropdown = Patterns.FromFile(WarehouseChamberImagePath+"DefaultskutypeDropdown.PNG", 0.9f);
                //SikuliAction.Hover(WarehouseChamberImagePath + "DefaultskutypeDropdown.PNG");
                session.Click(skudropdown, new Point(92, 0), 10f);

                var skutype0dropdown = Patterns.FromFile(WarehouseChamberImagePath+"skutype0Dropdown.png", 0.9f);
                session.Wait(skutype0dropdown, 10f);
                //SikuliAction.Hover(WarehouseChamberImagePath + "skutype0Dropdown.PNG");
                session.Click(skutype0dropdown, new Point(-94, 16), 10f);

                //SikuliAction.Hover(WarehouseChamberImagePath + "stocklessindicatorcheckbox.PNG");
                session.Click(stocklessindicatorcheckbox, new Point(100, 1), 10f);
                ss.screenshotpranas(folder, date, "AddSkuType");
          
                var addskutype_save = Patterns.FromFile(WarehouseChamberImagePath+"Add SKU Type Window Save.PNG", 0.9f);
                //SikuliAction.Hover(WarehouseChamberImagePath + "Add SKU Type Window Save.PNG");
                session.Click(addskutype_save, 10f);

                var warningAboutToRemoveSKU = Patterns.FromFile(WarehouseChamberImagePath + "Warning You are about to remove the Selected SKU.PNG", 0.9f);
                var confirmSaveExceptionSKU = Patterns.FromFile(WarehouseChamberImagePath + "StocklessexceptionForSKUwarning.PNG", 0.9f);

                if (session.Exists(warningAboutToRemoveSKU))
                {
                    //SikuliAction.Hover(WarehouseChamberImagePath + "Warning You are about to remove the Selected SKU.PNG");
                    session.Click(warningAboutToRemoveSKU, 5f);
                    //SikuliAction.Hover(WarehouseChamberImagePath + "StocklessexceptionForSKUwarning.PNG");
                    session.Click(confirmSaveExceptionSKU, new Point(-31, 34), 5f);
                    Console.WriteLine("Unexpected Popup detected!");
                }
                else
                {
                    session.Wait(areyousureyouwanttosave_ok, 10f);
                    //SikuliAction.Hover(WarehouseChamberImagePath + "Are you sure you want to save.PNG");
                    session.Click(areyousureyouwanttosave_ok, new Point(-27, 10), 10f);
                }
                

                /*
                 * Code to handle pop up here
                 * */
               /* try
                {
                    session.Click(warningAboutToRemoveSKU, 5f);
                    session.Click(confirmSaveExceptionSKU, 5f);
                    Console.WriteLine("Unexpected Popup detected!");
                }catch(TimeoutException){
                    Console.WriteLine("No Unexpected Popup detected!");
                }*/

               

                //click ok on confirm pop up
                session.Wait(confirmpopup, 10f);
                //SikuliAction.Hover(WarehouseChamberImagePath + "confirmpopup.PNG");
                session.Click(confirmpopup, new Point(-5, 16), 10f);
                

                var NewChamberdropdownchoices = Patterns.FromFile(WarehouseChamberImagePath+"NewChamberdropdownchoices.png", 0.9f);

                ss.screenshotpranas(folder, date, "WareHouseChamberBefore");                

                if (chambervalue.Equals("Closed"))
                {
                    session.Click(NewChamberdropdownchoices, new Point(-35, -2), 10f);
                }
                else if (chambervalue.Equals("WRP"))
                {
                    session.Click(NewChamberdropdownchoices, new Point(-36, 25), 10f);
                }

                var EditChamber = Patterns.FromFile(WarehouseChamberImagePath+"Edit Chamber.PNG", 0.9f);
                session.Wait(EditChamber, 30f);
                ss.screenshotpranas(folder, date, "WareHouseChamberAfter"); 
                
                var ExitMain = Patterns.FromFile(@"C:\Users\A8LL\Documents\Visual Studio 2013\Projects\NordstromAutomation\ObjectImages\Main\ExitMain.png", 0.9f);

                session.Click(ExitMain, 10f);

            }
            driver.Close();

        }

        public void Hover()
        {

            using (var runtime = Sikuli.CreateRuntime())
            {
                runtime.Start();

                var result = runtime.Run(
                  @"print ""RESULT: OK"" if exist(""C:\\Users\\A8LL\\Documents\\Visual Studio 2013\\Projects\\NordstromAutomation\\ObjectImages\\Login\\DMStart.PNG"") else ""RESULT: FAIL""",
                  "RESULT:",
                  0
                  );

                //NUnit.Framework.Assert.That(result, Does.Contain("RESULT: OK"));
            }

        }
    }
}
