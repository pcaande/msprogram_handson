﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium;
using NordstromAutomation.Functions;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;
using NordstromAutomation.Pages;

namespace NordstromAutomation.TestScripts.PoC_Scripts
{
    /// <summary>
    /// TS.01_Validate Product Hierarchy Configurations 
    /// Validate the main spine Product hierarchy structure is correct and 
    /// complete based on Nordstrom implemention at RPAS Fusion
    /// </summary>

    [TestClass]
    public class POC_Validate_Product_Hierarchy_Configurations : TestBase
    {

        //Functions
        Validate val = new Validate();
        Click click = new Click();
        Wait wait = new Wait();
        Keyboard kb = new Keyboard();
        Select select = new Select();
        ScreenShot ss = new ScreenShot();

        //Pages
        DimensionPage dp = new DimensionPage(driver);
        NavigationPage np = new NavigationPage(driver);
        FramesPage fp = new FramesPage(driver);
        SelectDomainOnNewWB sdonw = new SelectDomainOnNewWB(driver);
        WorkbookWizardPage wwp = new WorkbookWizardPage(driver);
        TopBarGlobalPage tbgp = new TopBarGlobalPage(driver);
        LogoutPage logout = new LogoutPage();
        LoginPage login = new LoginPage();

        String folder = "TS01_01_Validate_Product_Hierarchy_Configurations";
        String date = DateTime.Now.ToString("MMddyyyy_hhmm");
        String domainName = "global";

        String[] validations = {"VPN : Color : Size : Pack Size",
                                   "VPN: Color: Size",
                                   "SKU Grouping",
                                   "VPN: Color",
                                   "VPN",
                                   "Subclass",
                                   "Class",
                                   "Department",
                                   "Subdivision",
                                   "Division",
                                   "Company"
                                   };

        [TestMethod]
        public void POC_Validate_Product_Hierarchy_ConfigurationsMethod()
        {
            //Login
            login.successfullLogin(driver);
            ss.screen_shot(driver, folder, date, "AfterLogin");

            //On the taskflow pane, select Analyzing activity 
            //> Store Replenishment task > Sales Order Inventory step > then click the Create New Workbook icon
            //> Sales Order Inventory step 
            //then click the Create New Workbook icon
            np.NavigateToAndCreateWB_AnalyzingStoreReplenishmentSalesOrdersInventory();

            //Select subclass option - Already default option        
            //Select any subclass from the list 
            fp.WaitForFrameToBeAvailableAndSwitchToIt();
            sdonw.SelectDomainName(domainName);
            ss.screen_shot(driver, folder, date, "SubClass");

            //Click on OK button 
            sdonw.clickOK();

            //Click on Dimension button 
            fp.WaitForFrameToBeAvailableAndSwitchToIt();
            ss.screen_shot(driver, folder, date, "SKU");

            wwp.clickOnDimensionButton();

            //Validate that the main spine of the SKU (product hier) is correct 
            dp.validateIfMultipleTextisDisplayed(driver, validations);
            ss.screen_shot(driver, folder, date, "ProductSpineHier");

            dp.clickCancel();

            fp.SwitchToDefaultContent();
            fp.WaitForFrameToBeAvailableAndSwitchToIt();
            wwp.clickCancel();

            //wait for logoutlink

            fp.SwitchToDefaultContent();

            //Click logout link
            tbgp.clickHomeLogout();

            logout.WaitForLogoutScreen(driver);
        }     

    }
}
