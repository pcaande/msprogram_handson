﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium;
using NordstromAutomation.Functions;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;
using NordstromAutomation.Pages;

namespace NordstromAutomation.TestScripts.Configurations
{
    /// <summary>
    /// TS.02_Validate Product Hierarchy Configurations 
    /// Validate the main spine Location hierarchy structure is correct 
    /// and complete based on Nordstrom implemention at RPAS Fusion 
    /// </summary>

    [TestClass]
    public class TS02_01_Validate_Location_Hierarchy_Configurations : TestBase
    {

        //Functions
        Validate val = new Validate();
        Click click = new Click();
        Wait wait = new Wait();
        Select select = new Select();
        Keyboard kb = new Keyboard();
        ScreenShot ss = new ScreenShot();

        //Pages
        DimensionPage dp = new DimensionPage(driver);
        NavigationPage np = new NavigationPage(driver);
        FramesPage fp = new FramesPage(driver);
        SelectDomainOnNewWB sdonw = new SelectDomainOnNewWB(driver);
        WorkbookWizardPage wwp = new WorkbookWizardPage(driver);
        TopBarGlobalPage tbgp = new TopBarGlobalPage(driver);
        LogoutPage logout = new LogoutPage();
        LoginPage login = new LoginPage();

        String folder = "TS02_01_Validate_Location_Hierarchy_Configurations";
        String date = DateTime.Now.ToString("MMddyyyy_hhmm");
        String domainName = "global";

        String[] validations = {"Store",
                                   "Site",
                                   "Region",
                                   "Selling Channel",
                                   "Market/Price Type",
                                   "Company"
                                   };
        [TestMethod]
        public void TS02_01_Validate_Location_Hierarchy_ConfigurationsMethod()
        {
            

            //Login
            login.successfullLogin(driver);
            ss.screen_shot(driver, folder, date, "AfterLogin");

            //On the taskflow pane, select Analyzing activity 
            //> Store Replenishment task > Sales Order Inventory step > then click the Create New Workbook icon
            //> Sales Order Inventory step 
            //then click the Create New Workbook icon
            np.NavigateToAndCreateWB_AnalyzingStoreReplenishmentSalesOrdersInventory();

            ///Select subclass option - Already default option        
            //Select any subclass from the list 
            fp.WaitForFrameToBeAvailableAndSwitchToIt();
            sdonw.SelectDomainName(domainName);
            ss.screen_shot(driver, folder, date, "SubClass");

            //Click on OK button 
            sdonw.clickOK();

            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //Add all skus then next
            wwp.AddAllSkusThenNext();
            ss.screen_shot(driver, folder, date, "StoreSelection");
            //Click Dimension Button
            wwp.clickOnDimensionButton();
            
            /* The following main spine of location hierarchy exist and complete */           
            dp.validateIfMultipleTextisDisplayed(driver, validations);
            ss.screen_shot(driver, folder, date, "LocationSpineProductHier");

            dp.clickCancel();

            fp.SwitchToDefaultContent();
            fp.WaitForFrameToBeAvailableAndSwitchToIt();
            wwp.clickCancel();

            //wait for logoutlink

            fp.SwitchToDefaultContent();

            //Click logout link
            tbgp.clickHomeLogout();

            logout.WaitForLogoutScreen(driver);
            
        }
       

    }
}
