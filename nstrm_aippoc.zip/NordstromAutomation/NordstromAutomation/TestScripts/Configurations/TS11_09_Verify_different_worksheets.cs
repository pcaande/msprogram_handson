﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using NordstromAutomation.Functions;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using NordstromAutomation.Pages;



namespace NordstromAutomation.TestScripts.Configurations
{
    /// <summary>
    /// TS.11_Verify different worksheets under activity workbooks defined as hidden or displayed 
    /// Validate different worksheets that should be visible under Analyzing activity, 
    /// Store Replenishment task and Sales, Orders & Inventory step 
    /// </summary>
    [TestClass]
    public class TS11_09_Verify_different_worksheets : TestBase
    {
        
        //Functions
        Click click = new Click();
        Enter enter = new Enter();
        Validate val = new Validate();
        Wait wait = new Wait();
        Select select = new Select();
        ScreenShot ss = new ScreenShot();

        //Pages
        MeasuresPage mp = new MeasuresPage(driver);
        SRPReplenishmentSummary_SKUStoreDay srp = new SRPReplenishmentSummary_SKUStoreDay(driver);
        TopBarGlobalPage tbgp = new TopBarGlobalPage(driver);
        NavigationPage np = new NavigationPage(driver);
        FramesPage fp = new FramesPage(driver);
        SelectDomainOnNewWB sdonw = new SelectDomainOnNewWB(driver);
        WorkbookWizardPage wwp = new WorkbookWizardPage(driver);
        WorkbookPage wp = new WorkbookPage(driver);
        LogoutPopUpPage lpup = new LogoutPopUpPage(driver);
        LogoutPage logout = new LogoutPage();
        LoginPage login = new LoginPage();

        String folder = "TS11_09_Verify_different_worksheets";
        String date = DateTime.Now.ToString("MMddyyyy_hhmm");

        String DomainName = "global";
        String sku = "3441";// -- (ORIG)91941646 -- (DEV06)1014532779 -- (DEV01)3441 -- (TST05)1004405728 --36018401

        String[] ExpectedWorksheets = {"Company Level Inventory Analysis",
                        "Inventory Packsize View",
                        "Receipt Packsize Detail",
                        "SRP Replenishment Summary (SKU/Store/Day)",
                       "WH Inventory Analysis (SKU Group/Warehouse/Day)"};

        [TestMethod]
        public void TS11_09_Verify_different_worksheetsTestMethod()
        {
            //Login
            login.successfullLogin(driver);
            ss.screen_shot(driver, folder, date, "AfterLogin");

            //Navigate to worksheet by creating workbook under this path  Analyzing activity
            //> Store Replenishment task and Sales 
            //> Alerts & Exceptions
            np.NavigateToAndCreateWB_AnalyzingStoreReplenishmentSalesOrdersInventory();

            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //Select any subclass from the list 
            sdonw.SelectDomainName(DomainName);
            ss.screen_shot(driver, folder, date, "Subclass");

            //Click on OK button 
            sdonw.clickOK();

            //Switch to iframe on pop up window
            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //search sku ad, add all associated stores, add all days
            wwp.SearchSKU_AddAllStore_AllDays(sku, folder, date);

            //Long load creating workbook
            wait.WaitForLoadingCreatingWorkbook(driver);


            //wait for workbook to load.
            fp.SwitchToDefaultContent();
            wait.WaitForWorkBookToLoad(driver);
            ss.screen_shot(driver, folder, date, "WorkBookCreated");

            List<IWebElement> children = wp.getWorksheetWebElement();

            String[] grandchildren = wp.getWorkSheetIDs(children);

            Console.WriteLine("Expected Number of Sheets: " + ExpectedWorksheets.Length
                                + "\nActual Number of Sheets: " + grandchildren.Length);
            //Validate if expected number of worksheets are met
            Assert.IsTrue(grandchildren.Length == grandchildren.Length);

            //Validate expected vs actual worksheets
            wp.ValidateExpectedAndActualWorksheets(folder, date, ExpectedWorksheets, grandchildren, children);

            //Click logout link
            tbgp.clickLogout();

            fp.WaitForFrameToBeAvailableAndSwitchToIt();

            //Click Do not Save
            lpup.DoNotSave();

            logout.WaitForLogoutScreen(driver);

        }

       
    }
}
