﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NordstromAutomation.Functions;
using NordstromAutomation.Pages;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordstromAutomation.TestScripts
{

    [TestClass]
    public class TestBase
    {

        private static Wait wait = new Wait();
        public static IWebDriver driver;

        //ENVIRONMENT DETAILS
        //TST01 - http://wlshost1-aip-at.nordstrom.net:8101/AIP/faces/workbook-task-flow/workbook            
        //TST05 - http://wlshost1-aip-tst05.nordstrom.net:8101/aipop/faces/Login.jspx
        //TST09 - http://wlshost1-aip-tst09.nordstrom.net:8101/aipop/faces/Login.jspx

        //DEV01 - http://wlshost1-aip-dev01.nordstrom.net:8101/AIP/faces/Login.jspx
        //DEV03 - http://wlshost1-aip-dev03.nordstrom.net:8101/AIP/faces/Login.jspx
        //DEV06 - http://wlshost1-aip-dev06.nordstrom.net:8101/AIP/faces/Login.jspx

        private static string url = "http://wlshost1-aip-dev01.nordstrom.net:8101/AIP/faces/Login.jspx";

        static TestBase()
        {
            FirefoxProfile profile = new FirefoxProfile();
            FirefoxBinary binary = new FirefoxBinary();
            //Change path to download path of firepath and firebug
            profile.AddExtension(@"C:\Users\A8LL\Downloads\firepath-0.9.7.1-fx.xpi");
            profile.AddExtension(@"C:\Users\A8LL\Downloads\firebug-2.0.14-fx.xpi");
            profile.SetPreference("extensions.firebug.currentVersion", "2.0.14");
            driver = new FirefoxDriver(binary, profile, TimeSpan.FromMinutes(3));
        }

        [TestInitialize()]
        public void Initialize()
        {
            driver.Navigate().GoToUrl(url);
            driver.Manage().Window.Maximize();
            wait.WaitForReady(driver, TimeSpan.FromSeconds(30));  
        }

       [TestCleanup()]
        public void TestCleanup()
        {
            driver.Close();
            driver = null;
        }

    }
}
