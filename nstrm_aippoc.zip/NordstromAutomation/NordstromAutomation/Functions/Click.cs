﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;


namespace NordstromAutomation.Functions
{
    class Click
    {
        Wait w = new Wait();
        public void clickByName(IWebDriver driver, String name)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            wait.Until(ExpectedConditions.ElementToBeClickable(By.Name(name)));

            driver.FindElement(By.Name(name)).Click();
        }

        public void clickById(IWebDriver driver, String id)
        {

            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            wait.Until(ExpectedConditions.ElementToBeClickable(By.Id(id)));

            driver.FindElement(By.Id(id)).Click();
            
        }

        public void clickByXpath(IWebDriver driver, String xpath)
        {

            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath(xpath)));

            driver.FindElement(By.XPath(xpath)).Click();

        }

        public void clickByWebElement(IWebDriver driver, IWebElement element)
        {

            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            wait.Until(ExpectedConditions.ElementToBeClickable(element));

            element.Click();

        }

        public void ClickBy_WithTimeSpan(IWebDriver driver, By by, TimeSpan seconds)
        {

            var wait = new WebDriverWait(driver, seconds);
            wait.Until(ExpectedConditions.ElementToBeClickable(by));

            driver.FindElement(by).Click();

        }
        


    }
}
