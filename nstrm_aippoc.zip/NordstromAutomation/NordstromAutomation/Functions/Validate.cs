﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NordstromAutomation.Functions;
using NUnit.Framework;
using OpenQA.Selenium.Support.UI;
namespace NordstromAutomation.Functions
{
    class Validate
    {

        Wait wait = new Wait();

        public void validateIfDisplayed(IWebDriver driver, string path, string validation)
        {
            if (driver.FindElement(By.Id(path)).Displayed)
            {
                //Console.WriteLine("Pass: Element " + validation + " Found !");
                if (driver.FindElement(By.Id(path)).Text.Equals(validation))
                {
                    Console.WriteLine("Pass: Element " + validation + " Found !");
                }
                else
                {
                    Console.WriteLine("Fail: Element " + validation + " Found !");
                }
            }
            else
            {
                Console.WriteLine("Object " + path + "  Not Found !");
            }

        }
        [TestMethod]
        public void validateIfTextisDisplayed(IWebDriver driver, string path, string validation)
        {

                wait.WaitForElementId(driver,path);

                try
                {
                    Microsoft.VisualStudio.TestTools.UnitTesting.Assert.IsTrue(driver.FindElement(By.Id(path)).Text.Contains(validation));
                    Console.WriteLine("Pass: Element " + validation + " Found !");
                }
                catch (AssertFailedException)
                {
                    
                    Console.WriteLine("Fail: Element " + validation + " Not Found !");
                }


        }

        public void validateIfMultipleTextisDisplayed(IWebDriver driver, string path, string[] validation)
        {
            
            wait.WaitForElementId(driver, path);
            for (int i = 0; i < validation.Length; i++ )
            {
                Console.WriteLine("===================================================================");
                try
                {
                    Microsoft.VisualStudio.TestTools.UnitTesting.Assert.IsTrue(driver.FindElement(By.Id(path)).Text.Contains(validation[i]));
                    Console.WriteLine("Pass: Element " + validation[i] + " Found !");
                }
                catch (AssertFailedException)
                {

                    Console.WriteLine("Fail: Element " + validation[i] + " Not Found !");
                }
                
            }

        }

        public bool IsElementPresent(IWebDriver driver, By by)
        {
            try
            {
                driver.FindElement(by);
                //var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(5));
                //wait.Until(ExpectedConditions.ElementIsVisible(by));
                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }


    }
}
