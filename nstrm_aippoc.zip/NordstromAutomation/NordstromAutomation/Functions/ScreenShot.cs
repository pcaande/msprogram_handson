﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NordstromAutomation.Functions;

namespace NordstromAutomation.Functions
{
    class ScreenShot
    {
        Wait w = new Wait();

        public void screen_shot(IWebDriver driver, String folder, String date, String filename)
        {

            w.WaitForReady(driver, TimeSpan.FromSeconds(60));
            // Specify a name for your top-level folder. 
            //string path = @"C:\Users\A8LL\Documents\Visual Studio 2013\Projects\NordstromAutomation\Screenshots";
            string path = Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory()))) + @"\Screenshots";
            // To create a string that specifies the path to a subfolder under your  
            // top-level folder, add a name for the subfolder to folderName. 
            path = System.IO.Path.Combine(path, folder);
            path = System.IO.Path.Combine(path, date);

            System.IO.Directory.CreateDirectory(path);
            Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();
            ss.SaveAsFile(path + "\\" + filename + ".png", System.Drawing.Imaging.ImageFormat.Png);
        }

        public void screenshotpranas(String folder, String date, String filename)
        {
            //string path = @"C:\Users\A8LL\Documents\Visual Studio 2013\Projects\NordstromAutomation\Screenshots";
            string path = Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory()))) + @"\Screenshots";
            path = System.IO.Path.Combine(path, folder);
            path = System.IO.Path.Combine(path, date);
            System.IO.Directory.CreateDirectory(path);

            Image screen = Pranas.ScreenshotCapture.TakeScreenshot(true);
            screen.Save(path + "\\" + filename + ".png", System.Drawing.Imaging.ImageFormat.Png);


        }
    }
}
