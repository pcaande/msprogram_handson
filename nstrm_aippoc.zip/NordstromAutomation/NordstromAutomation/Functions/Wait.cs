﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordstromAutomation.Functions
{
    class Wait
    {
        //busy icon - .//*[@id='b:pt_si1']/img[@alt='Busy']
        //idle icon - .//*[@id='b:pt_si1']/img[@alt='Idle']
        public void waitForBusyTopRightImageToDisappear(IWebDriver driver)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(120));
            wait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath(".//*[@id='b:pt_si1']/img[@alt='Busy']")));
        }

        public void WaitForElementId(IWebDriver driver, String id)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            WaitForReady(driver, TimeSpan.FromSeconds(60));
            IWebElement category = wait.Until<IWebElement>((d) =>
            {
                return d.FindElement(By.Id(id));
            });
            
        }

        public void WaitForElementXpath(IWebDriver driver, String xpath)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            WaitForReady(driver, TimeSpan.FromSeconds(60));
            IWebElement category = wait.Until<IWebElement>((d) =>
            {
                return d.FindElement(By.XPath(xpath));
            });
        }

        public void WaitForFrameToBeAvailableAndSwitchToIt(IWebDriver driver, String frame)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            for (int i = 0; i < 6; i++ )
            {
                try
                {
                    wait.Until(ExpectedConditions.FrameToBeAvailableAndSwitchToIt(By.XPath(frame)));
                    break;
                }
                catch (NoSuchElementException)
                {
                    Console.WriteLine("iFrame not detected! Retrying..." + i);
                    driver.SwitchTo().DefaultContent();
                }
                catch (WebDriverTimeoutException)
                {
                    Console.WriteLine("iFrame not detected! Retrying..." + i);
                    driver.SwitchTo().DefaultContent();
                }
            }
        }

        public void WaitForInvisibilityOfElementLocated(IWebDriver driver, String id)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(120));
            wait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.Id(id)));
            
        }

        public void WaitForInvisibilityOfElementLocatedBy(IWebDriver driver, By by, int seconds)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(seconds));
            wait.Until(ExpectedConditions.InvisibilityOfElementLocated(by));

        }

        public void WaitForInvisibilityOfElementWithText(IWebDriver driver, String id, String text)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            wait.Until(ExpectedConditions.InvisibilityOfElementWithText(By.Id(id), text));

        }

        public void WaitForVisbilityId(IWebDriver driver, string id)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            WaitForReady(driver, TimeSpan.FromSeconds(60));
            wait.Until(ExpectedConditions.ElementIsVisible(By.Id(id)));
            
        }

        public void WaitForWorkBookToLoad(IWebDriver driver)
        {
            WaitForVisbilityId(driver, "b:winNav::tabh::oc");
        }


        public void WaitForClickableElement(IWebDriver driver, IWebElement element)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            WaitForReady(driver, TimeSpan.FromSeconds(60));
            wait.Until(ExpectedConditions.ElementToBeClickable(element));

        }

        public void WaitForVisbilityBy(IWebDriver driver, By by)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            WaitForReady(driver, TimeSpan.FromSeconds(60));
            wait.Until(ExpectedConditions.ElementIsVisible(by));
            //ExpectedConditions.TitleIs
        }

        public String switchToMostCurrentFrame(IWebDriver driver)
        {

            List<IWebElement> frames = new List<IWebElement>(driver.FindElements(By.TagName("iframe")));
            Console.WriteLine("Number of Frames: " + frames.Count);
            for (int i = 0; i < frames.Count; i++)
            {
                Console.WriteLine("frame[" + i + "]: " + frames[i].GetAttribute("id").ToString());
            }

            driver.SwitchTo().Frame(frames.Last());
            driver.SwitchTo().Frame(0);

            IWebElement iframe = driver.FindElement(By.Id("iframe1"));
            driver.SwitchTo().Frame(iframe);
            driver.SwitchTo().ParentFrame();

            return frames.Last().GetAttribute("id").ToString();
        }

        public void WaitForElementToAppearThenDisappear(IWebDriver driver, String id)
        {
            WaitForVisbilityId(driver, id);
            WaitForInvisibilityOfElementLocated(driver, id);
        }

        public void WaitForLoadingCreatingWorkbook(IWebDriver driver)
        {
            //Long load creating workbook
            WaitForElementToAppearThenDisappear(driver, "pt1:ptss:mdialog::contentContainer");
        }

        public void WaitForElementToAppearThenDisappearBy(IWebDriver driver, By by, int seconds)
        {
            WaitForVisbilityBy(driver, by);
            WaitForInvisibilityOfElementLocatedBy(driver, by, seconds);
        }

        public void WaitForReady(IWebDriver driver, TimeSpan seconds)
        {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.Until(d =>
            {
                return WaitForPageLoad(driver, seconds);
            });
            WaitForFetchingData(driver);
            /*WaitForDocumentReady(driver, seconds);
            WaitForAjaxComplete(driver, 11);
            WaitForDocumentReady(driver, seconds);*/
        }


        public static bool WaitForPageLoad(IWebDriver driver, TimeSpan waitTime)
        {
            WaitForDocumentReady(driver, waitTime);
            bool ajaxReady = WaitForAjaxReady(driver, waitTime);
            
            WaitForDocumentReady(driver, waitTime);

            return ajaxReady;
        }

        private static void WaitForDocumentReady(IWebDriver driver, TimeSpan waitTime)
        {
            //var timeout = new TimeSpan(0, 0, Constants.DefaultTimeout);
            var wait = new WebDriverWait(driver, waitTime);

            var javascript = driver as IJavaScriptExecutor;
            if (javascript == null)
                throw new ArgumentException("driver", "Driver must support javascript execution");

            wait.Until((d) =>
            {
                try
                {
                    string readyState = javascript.ExecuteScript(
                        "if (document.readyState) return document.readyState;").ToString();
                    return readyState.ToLower() == "complete";
                }
                catch (InvalidOperationException e)
                {
                    //Window is no longer available
                    return e.Message.ToLower().Contains("unable to get browser");
                }
                catch (WebDriverException e)
                {
                    //Browser is no longer available
                    return e.Message.ToLower().Contains("unable to connect");
                }
                catch (Exception)
                {
                    return false;
                }
            });

        }

        private static bool WaitForAjaxReady(IWebDriver driver, TimeSpan waitTime)
        {
            System.Threading.Thread.Sleep(1000);
            WebDriverWait wait = new WebDriverWait(driver, waitTime);
            return wait.Until<bool>((d) =>
            {
                return driver.FindElements(By.CssSelector(".waiting, .tb-loading")).Count == 0;
                //return (bool) ((IJavaScriptExecutor)driver).ExecuteScript("return window.jQuery != undefined && jQuery.active == 0");
            });
        }

        

        public static void WaitForAjaxComplete(IWebDriver driver, int maxSeconds)
        {
            bool is_ajax_compete = false;
            for (int i = 1; i <= maxSeconds; i++)
            {
                is_ajax_compete = (bool) ((IJavaScriptExecutor)driver).ExecuteScript("return window.jQuery != undefined && jQuery.active == 0");
            if (is_ajax_compete)
            {
                return;
            }
                System.Threading.Thread.Sleep(1000);
            }
                //throw new Exception("Timed out after " + maxSeconds + " seconds");
         }


        public void WaitForFetchingData(IWebDriver driver)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(20));
            wait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath(".//*[text()= 'Fetching Data...' and contains(@style, 'display: block')]")));
            
        }



    }
}
