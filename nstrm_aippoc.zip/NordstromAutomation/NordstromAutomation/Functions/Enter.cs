﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace NordstromAutomation.Functions
{
    class Enter
    {

        public void enterByName(IWebDriver driver, string name, string key)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            wait.Until(ExpectedConditions.ElementIsVisible(By.Name(name)));

            driver.FindElement(By.Name(name)).SendKeys(key);

        }

        public void enterById(IWebDriver driver, string id, string key)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            wait.Until(ExpectedConditions.ElementIsVisible(By.Id(id)));

            driver.FindElement(By.Id(id)).SendKeys(key);

        }

        public void enterByWebElement(IWebDriver driver, IWebElement element, string key)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            wait.Until(ExpectedConditions.ElementToBeClickable(element));
            element.Clear();
            element.SendKeys(key);
        }

    }
}
