﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordstromAutomation.Functions
{
    class Keyboard
    {


        public void KeyBoardShortcut_AltShiftKeyEnter(IWebDriver driver, String key)
        {

            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until(ExpectedConditions.ElementIsVisible(By.TagName("html")));
           

                driver.FindElement(By.TagName("html")).SendKeys(Keys.Alt + Keys.Shift + key + Keys.Enter);
        }

        public void KeyBoardShortcut_PageDown(IWebDriver driver)
        {

            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until(ExpectedConditions.ElementIsVisible(By.Id("pt1:wizDim:dimTSDC:dimPopTable::scroller")));


            driver.FindElement(By.Id("pt1:wizDim:dimTSDC:dimPopTable::scroller")).SendKeys(Keys.PageDown);
        }

    }
}
