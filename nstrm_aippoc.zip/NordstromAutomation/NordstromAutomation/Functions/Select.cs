﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace NordstromAutomation.Functions
{
    class Select
    {

        public void selectById(IWebDriver driver, string id, string key)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
                wait.Until(ExpectedConditions.ElementToBeClickable(By.Id(id)));
                var selectElement = new SelectElement(driver.FindElement(By.Id(id)));
                selectElement.SelectByText(key);
                
                
            }
            catch (StaleElementReferenceException)
            {
                var selectElement = new SelectElement(driver.FindElement(By.Id(id)));
                selectElement.SelectByText(key);
            }

        }

        public void selectByIdByIndex(IWebDriver driver, string id, int index)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
                wait.Until(ExpectedConditions.ElementToBeClickable(By.Id(id)));
                var selectElement = new SelectElement(driver.FindElement(By.Id(id)));
                
                selectElement.SelectByIndex(index);

            }
            catch (StaleElementReferenceException)
            {
                var selectElement = new SelectElement(driver.FindElement(By.Id(id)));
                selectElement.SelectByIndex(index);
            }

        }

        protected void clickOptionInList(IWebDriver driver, string listControlId, string optionText)
        {
            driver.FindElement(By.XPath("//select[@id='" + listControlId + "']/option[contains(.,'" + optionText + "')]")).Click();
        }

    }
}
